from django.conf.urls import url, include
from superadmin import views as v

urlpatterns = [
    url(r'^$',v.LandingPage.as_view(), name='landing-page'),
    url(r'^restaurants/$', v.ListRestaurants.as_view(), name='list-restaurants'),
    url(r'^add-restaurant/$', v.AddRestaurant.as_view(), name='add-restaurant'),
	url(r'^edit-restaurant/(?P<pk>\d+)/$',v.EditRestaurant.as_view(),name='edit-restaurant'),
    
]
