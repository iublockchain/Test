from django.shortcuts import render,redirect
from user.models import UserProfile
from restaurant.models import Restaurant
from restaurant.forms import RestaurantForm,RestaurantAdminForm
from django.views.generic import View,TemplateView,ListView
from django.http import Http404
from django.contrib import messages
from Project.utils import geocode


class LandingPage(TemplateView):
    template_name='superadmin/landing_page.html'


class ListRestaurants(ListView):
    template_name='superadmin/list_restaurants.html'
    def get_queryset(self,*args,**kwargs):
        return Restaurant.objects.filter(is_active=True)

class AddRestaurant(TemplateView):
    template_name='superadmin/add_restaurant.html'
    def get_context_data(self,*args,**kwargs):
        context=super(AddRestaurant,self).get_context_data(*args,**kwargs)
        context['restaurant_form']=RestaurantForm()
        context['admin_form']=RestaurantAdminForm()
        return context

    def post(self,request):
        form=RestaurantForm(request.POST,request.FILES)
        admin_form=RestaurantAdminForm(request.POST)
        if form.is_valid():
            if admin_form.is_valid():
                res=form.save(commit=False)
                try:
                    loc=geocode(res.full_address)
                    if loc:
                        res.lat=loc['lat']
                        res.lng=loc['lng']
                except:
                    messages.error(request,'Geo Coding of restaurant address failed')
                res.save()
                admin=admin_form.save(commit=False)
                admin.set_username()
                admin.set_password(admin_form.cleaned_data.get('password'))
                admin.user_type='BUSINESS_ADMIN'
                admin.status='ACTIVE'
                admin.restaurant=res
                admin.save()
                return redirect('superadmin:list-restaurants')
        context={'restaurant_form':form,'admin_form':admin_form}
        return render(request,self.template_name,context)



class EditRestaurant(TemplateView):
    template_name='superadmin/edit_restaurant.html'
    def get_context_data(self,pk,*args,**kwargs):
        context=super(EditRestaurant,self).get_context_data(*args,**kwargs)
        restaurant=Restaurant.objects.filter(id=pk).first()
        if not restaurant:
            raise Http404
        admin=UserProfile.objects.filter(restaurant=restaurant,user_type='BUSINESS_ADMIN',is_active=True).first()
        context['restaurant_form']=RestaurantForm(instance=restaurant)
        context['admin_form']=RestaurantAdminForm(instance=admin,no_password=True)
        return context

    def post(self,request,pk,*args,**kwargs):
        restaurant=Restaurant.objects.filter(id=pk).first()
        if not restaurant:
            raise Http404
        admin=UserProfile.objects.filter(restaurant=restaurant,user_type='BUSINESS_ADMIN',is_active=True).first()
        form=RestaurantForm(request.POST,request.FILES,instance=restaurant)
        admin_form=RestaurantAdminForm(request.POST,instance=admin,no_password=True)
        if form.is_valid():
            if admin_form.is_valid():
                admin=admin_form.save()
                res=form.save(commit=False)
                try:
                    loc=geocode(res.full_address)
                    if loc:
                        res.lat=loc['lat']
                        res.lng=loc['lng']
                except:
                    messages.error(request,'Geo Coding of restaurant address failed')
                res.save()
                return redirect('superadmin:list-restaurants')
        context={'restaurant_form':form,'admin_form':admin_form}
        return render(request,self.template_name,context)


class DeleteRestaurant(View):
    def post(self,request,pk,*args,**kwargs):
        Restaurant.objects.filter(id=pk).update(is_active=False)
        UserProfile.objects.filter(user_type='BUSINESS_ADMIN',restaurant__id=pk).update(is_active=False)
        messages.error(request,'restaurant deleted')
        return redirect('superadmin:list-restaurants')
