from django.apps import AppConfig


class SuperadminConfig(AppConfig):
    name = 'superadmin'
