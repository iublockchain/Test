from communications.models import SMS,Email
import requests
from datetime import timedelta,datetime
from django.db.models import Q
from django.core.management.base import BaseCommand
from django.conf import settings
import os
from threading import Thread
from django.db import connection
import time
from twilio.rest import Client
from copy import copy

# Use  `crontab -e` to set cron jobs
# Server configuration of crontab
# 0 8 * * * /home/en/bin/python3 /home/project/manage.py send >> /home/cron_send.log

# `service cron status` to know status of cron jobs running


class MailDict():
    data_dict={
        "personalizations": [{"to": [{"email":""}],"subject": ''}],
        "from": {"email": settings.EMAIL_SETTINGS.get('FROM_EMAIL'),
            'name':settings.EMAIL_SETTINGS.get('FROM_NAME')},
        "content": [{"type": "text/html","value": ""}]
        }
    @staticmethod
    def get_data(mail_obj):
        t=MailDict.data_dict['personalizations'][0]
        t['subject']=mail_obj.subject
        t['to'][0]['email']=mail_obj.to
        MailDict.data_dict['content'][0]['value']=mail_obj.content
        return copy(MailDict.data_dict)

    headers={'Authorization':'Bearer '+settings.EMAIL_SETTINGS.get('API_KEY'),
                'Content-Type':'application/json'
                }

def send_email(emails):
    try:
        for mail_obj in emails:
            r=requests.post(headers=MailDict.headers,url=settings.EMAIL_SETTINGS.get('SEND_URL'),json=MailDict.get_data(mail_obj))
            if r.status_code==202:                
                mail_obj.status='SENT'
            mail_obj.attempts_count+=1
            mail_obj.last_attempt_time=datetime.now()
            if mail_obj.attempts_count>=3:
                mail_obj.status='FAILED'
            mail_obj.save()
    except Exception as e:
        print(e)
        with open(settings.SENDER_LOG_FILE, 'a') as log_file:
            log_file.write('failed sending email with id '+str(mail_obj.id)+' at '+datetime.now().isoformat()+'\n')
    finally:
        connection.close()

def send_sms(pending_sms,client):
    try:
        for msg in pending_sms:
            mobile_no=str(msg.mobile_no).replace(' ','').replace('-','').strip()
            if not mobile_no.startswith('+1'):
                mobile_no='+1'+mobile_no
            message = client.messages.create(from_=settings.SMS_SETTINGS.get('FROM_NUMBER'),to=mobile_no,
                body=msg.message)
            msg.msg_id=message.sid
            msg.status='ATTEMPTED'
            msg.attempts_count+=1
            msg.last_attempt_time=datetime.now()
            msg.save()
        connection.close()
    except Exception as e:
        print(e)
        with open(settings.SENDER_LOG_FILE, 'a') as log_file:
            log_file.write('failed sending sms with id '+str(msg.id)+' at '+datetime.now().isoformat()+'\n')
    finally:
        connection.close()




class Command(BaseCommand):
    help = 'Sends Email and SMS'

    def add_arguments(self, parser):
        pass
        
    def handle(self, *args, **options):
        if os.path.isfile(settings.SENDER_LOCK_FILE):
            # mod_time=os.path.getmtime(settings.SENDER_LOCK_FILE)
            # time_diff=datetime.now()-datetime.utcfromtimestamp(mod_time)
            # print('time_diff===',time_diff)
            # if time_diff>timedelta(minutes=15):
                # os.remove(settings.SENDER_LOCK_FILE)
            # else:
            print('already running')
            return
        try:
            # Locking
            open(settings.SENDER_LOCK_FILE, 'a').close()

            # setting up twilio client
            client = Client(settings.SMS_SETTINGS.get('ACCOUNT_SID'),settings.SMS_SETTINGS.get('AUTH_TOKEN'))
            timegap=datetime.now()-timedelta(minutes=5)

            while True:
                # sending sms via threads
                thread_list=[]
                pending=SMS.objects.filter(Q(last_attempt_time__isnull=True)|Q(last_attempt_time__lte=timegap),
                    is_active=True,status='PENDING').order_by('attempts_count')
                no_of_sms=len(pending)
                print('sms==',pending)
                if no_of_sms>0:
                    no_of_threads=settings.MAX_SMS_SENDER_THREADS if no_of_sms >= settings.MAX_SMS_SENDER_THREADS else no_of_sms
                    per_thread_sms=round(no_of_sms/no_of_threads)
                    
                    for i,beg in enumerate(range(0,no_of_sms,per_thread_sms)):
                        t = Thread(name='sms'+str(i),target=send_sms,args=[pending[beg:beg+per_thread_sms],client])
                        t.start()
                        thread_list.append(t)

                # logging
                    with open(settings.SENDER_LOG_FILE, 'a') as log_file:
                        log_file.write(str(pending.count())+' SMS attempted by '+datetime.now().isoformat()+'\n')

                # sending emails via threads
                emails=Email.objects.filter(status='PENDING')
                print('emails=====',emails)
                no_of_emails=len(emails)
                if no_of_emails>0:
                    no_of_threads=settings.MAX_EMAIL_SENDER_THREADS if no_of_emails >= settings.MAX_EMAIL_SENDER_THREADS else no_of_emails
                    per_thread_email=round(no_of_emails/no_of_threads)
                    for i,beg in enumerate(range(0,no_of_emails,per_thread_email)):
                        t = Thread(name='email'+str(i),target=send_email,args=[emails[beg:beg+per_thread_email]])
                        t.start()
                        thread_list.append(t)
                
                # logging
                    with open(settings.SENDER_LOG_FILE, 'a') as log_file:
                        log_file.write(str(no_of_emails)+' emails attempted at'+datetime.now().isoformat()+'\n')

                for tt in thread_list:
                    tt.join()
                time.sleep(5)

            if os.path.isfile(settings.SENDER_LOCK_FILE):
                os.remove(settings.SENDER_LOCK_FILE)
        except Exception as e:
            print(e)
        finally:
            if os.path.isfile(settings.SENDER_LOCK_FILE):
                os.remove(settings.SENDER_LOCK_FILE)
