from django.contrib import admin
from communications.models import Email,SMS

admin.site.register(Email)
admin.site.register(SMS)