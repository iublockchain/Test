from django.db import models
from user.models import UserProfile


EMAIL_STATUS_CHOICES=(
    ('PENDING','Pending'),
    ('SENT','Sent'),
    ('FAILED','Failed'),
)

class Email(models.Model):
	to                  =   models.EmailField(null=False,blank=True,default='',verbose_name='to')
	subject             =   models.CharField(max_length=255,null=False,blank=False,default='')
	content             =   models.TextField(null=False,blank=False,default='')
	last_attempt_time   =   models.DateTimeField(null=True,blank=True,default=None)
	status              =   models.CharField(max_length=30,null=False,choices=EMAIL_STATUS_CHOICES,default='PENDING')
	attempts_count      =   models.IntegerField(null=False,blank=True,default=0)
	is_active           =   models.BooleanField(null=False,blank=True,default=True)
	created             =   models.DateTimeField(auto_now_add=True)
	updated             =   models.DateTimeField(auto_now=True)


SMS_STATUS_CHOICES=(
('PENDING','Pending'),
('ATTEMPTED','Attempted'),
('FAILED','Failed'),
('SUCCESS','Success'),
)

class SMS(models.Model):
	is_system_generated		=	models.BooleanField(null=False,default=False)
	message					=	models.TextField()
	sms_count				=	models.IntegerField(null=False,blank=True,default=1)
	mobile_no				=	models.CharField(max_length=30,null=False,blank=True)
	msg_id					=	models.CharField(max_length=255,null=True,blank=True)
	status					=	models.CharField(max_length=30,null=False,choices=SMS_STATUS_CHOICES,default='PENDING')
	last_attempt_time		=	models.DateTimeField(null=True,blank=True,default=None)
	last_status_check_time	=	models.DateTimeField(null=True,blank=True,default=None)
	attempts_count			=	models.IntegerField(null=False,blank=True,default=0)
	is_active				=	models.BooleanField(null=False,blank=True,default=True)
	created					=	models.DateTimeField(auto_now_add=True)
	updated					=	models.DateTimeField(auto_now=True)