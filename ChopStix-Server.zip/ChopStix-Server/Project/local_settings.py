import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

debug=True
allowed_hosts=['127.0.0.1','*']
domains=['127.0.0.1']
scheme='http'
secret_key='6_^s1$ndr$z%_2h3+m^x_yct%87f=abca93sd$z&1z7v$3eek0'
databases={
	'default': {
		'ENGINE': 'django.db.backends.sqlite3',
		'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
	}
}


sms_settings={
	'user':'username',
	'api_key':'2asdRDaddsdsdfgfggxO4Yi6X',
	'sender_id':'ChopStix',
	'ip':'127.0.0.1' #not used in settings. added for reference
}

send_sms_lock_file='/home/moustafaawad/send_sms.lock'

send_sms_log_file='/home/moustafaawad/send_sms_log'


static_root='/home/moustafaawad/chop-static/'
media_root='/home/moustafaawad/chop-media/'




geocoding_api_key = 'AIzaSyD6k3je6kjEYUtusaHtzSnIft6hHNtVcRA'

email_settings = ''
sender_lock_file = ''
sender_log_file = ''