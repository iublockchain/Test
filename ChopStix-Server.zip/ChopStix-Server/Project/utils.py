import pytz
from datetime import datetime
import re
from django.conf import settings
import requests
from django.utils import timezone

def validate_password(password):
	if len(password)<8:
		return False,'Password should be at least 8 characters long'
	if not any(char.isdigit() for char in password):
		return False,'Password should contain at least one digit'
	return True,''

def get_error(form):
	errors=dict(form.errors)
	key=tuple(errors.keys())[0]
	error=errors[key]
	key_replace_regex=(r'((non_field_errors)|(__all__))')
	key_replace_regex=re.compile(key_replace_regex)
	key=re.sub(key_replace_regex,'',key)
	if isinstance(error,(tuple,list)):
		return ((key +' : ') if key else '')+error[0]
	tkey=tuple(error.keys())[0]
	tkey=re.sub(key_replace_regex,'',tkey)
	message=((key +' : ') if key else '')+ error[tkey][0]
	return message

def utc_now():
	return datetime.now(pytz.utc)

def utc_today():
	return datetime.now(pytz.utc).date()

def localtime(utc_dt,request):
	if not utc_dt:
		return utc_dt
	if not utc_dt.tzinfo:
		utc_dt = utc_dt.replace(tzinfo=timezone.utc)
	user_tz_offset = request.COOKIES.get('tz_offset') if request else None
	user_tz_offset = int(user_tz_offset) if user_tz_offset else -360
	user_tz = timezone.get_fixed_timezone(user_tz_offset)
	return timezone.localtime(utc_dt,timezone=user_tz)


def geocode(full_address):
	url='https://maps.googleapis.com/maps/api/geocode/json'
	params={'address':full_address,'key':settings.GEOCODING_API_KEY}
	r= requests.post(url,params=params)
	result=r.json()
	# print('result====',result)
	if result['status']!='OK':
		print('geocoding result====',result)
		raise Exception('Request rejected')
	return result['results'][0]['geometry']['location']

	# from Project.utils import geocode
	# geocode('285 MLK Blvd, Apt. 2, Newark, New Jersey, 07102')




# {
#    "results" : [
#       {
#          "address_components" : [
#             {
#                "long_name" : "High Street",
#                "short_name" : "High St",
#                "types" : [ "route" ]
#             },
#             {
#                "long_name" : "Hastings",
#                "short_name" : "Hastings",
#                "types" : [ "postal_town" ]
#             },
#             {
#                "long_name" : "East Sussex",
#                "short_name" : "East Sussex",
#                "types" : [ "administrative_area_level_2", "political" ]
#             },
#             {
#                "long_name" : "England",
#                "short_name" : "England",
#                "types" : [ "administrative_area_level_1", "political" ]
#             },
#             {
#                "long_name" : "United Kingdom",
#                "short_name" : "GB",
#                "types" : [ "country", "political" ]
#             },
#             {
#                "long_name" : "TN34 3EY",
#                "short_name" : "TN34 3EY",
#                "types" : [ "postal_code" ]
#             }
#          ],
#          "formatted_address" : "High St, Hastings TN34 3EY, UK",
#          "geometry" : {
#             "bounds" : {
#                "northeast" : {
#                   "lat" : 50.8601041,
#                   "lng" : 0.5957329
#                },
#                "southwest" : {
#                   "lat" : 50.8559061,
#                   "lng" : 0.5906163
#                }
#             },
#             "location" : {
#                "lat" : 50.85830319999999,
#                "lng" : 0.5924594
#             },
#             "location_type" : "GEOMETRIC_CENTER",
#             "viewport" : {
#                "northeast" : {
#                   "lat" : 50.8601041,
#                   "lng" : 0.5957329
#                },
#                "southwest" : {
#                   "lat" : 50.8559061,
#                   "lng" : 0.5906163
#                }
#             }
#          },
#          "partial_match" : true,
#          "place_id" : "ChIJ-Ws929sa30cRKgsMNVkPyws",
#          "types" : [ "route" ]
#       }
#    ],
#    "status" : "OK"
# }