from django.shortcuts import render,redirect
from django.views.generic import TemplateView,View

class IndexLogin(View):
	template_name='website/index.html'

	def get(self,request):
		if request.user.is_authenticated:
			if request.user.user_type=='SUPER_ADMIN' and request.get_host().startswith('support.'):
				return redirect('superadmin:landing-page')
			elif request.user.user_type=='BUSINESS_ADMIN':
				return redirect('restaurant:list-orders')
		return render(request,self.template_name,{})
	
		
		





# def index(request):
# 	return render(request, 'website/index.html')

# def sign(request):
# 	return render(request, 'website/sign.html')

# def first(request):
# 	return HttpResponse("User successfully logged in <201>")