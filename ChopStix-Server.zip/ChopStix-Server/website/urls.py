from django.conf.urls import url, include
from website import views as v

urlpatterns = [
    url(r'^$', v.IndexLogin.as_view(), name='index'),

]
