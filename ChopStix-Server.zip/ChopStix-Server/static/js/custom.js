

function load_popup_async(source,modal_id)
    {
    $(".pre-loader").fadeIn("fast");
    after_show_fn=eval($(source).data('after-show'));
    $.ajax({url:$(source).data('url'),type:'get',
        success:(data)=>{$('#'+modal_id+' .modal-content').html(data);
        $('#'+modal_id).modal('show');
        if(after_show_fn)after_show_fn(source);
        },
        error:function(){alert('connection problem');},
        complete:function(){$(".pre-loader").fadeOut("fast");}
    });
    }

