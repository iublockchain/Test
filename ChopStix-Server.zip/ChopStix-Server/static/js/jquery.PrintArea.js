!function(t){var e=0,n="iframe",o="popup",r="loose",i="html5",a={mode:n,standard:i,popHt:500,popWd:400,popX:200,popY:200,popTitle:"",popClose:!1,extraCss:"",extraHead:"",retainAttr:["id","class","style"]},c={};t.fn.printArea=function(n){t.extend(c,a,n),e++;var o="printArea_";t("[id^="+o+"]").remove(),c.id=o+e;var r=t(this),i=d.getPrintWindow();d.write(i.doc,r),setTimeout(function(){d.print(i)},1e3)};var d={print:function(e){var n=e.win;t(e.doc).ready(function(){n.focus(),n.print(),c.mode==o&&c.popClose&&setTimeout(function(){n.close()},2e3)})},write:function(t,e){t.open(),t.write(d.docType()+"<html>"+d.getHead()+d.getBody(e)+"</html>"),t.close()},docType:function(){return c.mode==n?"":c.standard==i?"<!DOCTYPE html>":'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01'+(c.standard==r?" Transitional":"")+'//EN" "http://www.w3.org/TR/html4/'+(c.standard==r?"loose":"strict")+'.dtd">'},getHead:function(){var e="",n="";return c.extraHead&&c.extraHead.replace(/([^,]+)/g,function(t){e+=t}),t(document).find("link").filter(function(){var e=t(this).attr("rel");return"undefined"===t.type(e)==0&&"stylesheet"==e.toLowerCase()}).filter(function(){var e=t(this).attr("media");return"undefined"===t.type(e)||""==e||"print"==e.toLowerCase()||"all"==e.toLowerCase()}).each(function(){n+='<link type="text/css" rel="stylesheet" href="'+t(this).attr("href")+'" >'}),c.extraCss&&c.extraCss.replace(/([^,\s]+)/g,function(t){n+='<link type="text/css" rel="stylesheet" href="'+t+'">'}),"<head><title>"+c.popTitle+"</title>"+e+n+"</head>"},getBody:function(e){var n="",o=c.retainAttr;return e.each(function(){for(var e=d.getFormData(t(this)),r="",i=0;i<o.length;i++){var a=t(e).attr(o[i]);a&&(r+=(r.length>0?" ":"")+o[i]+"='"+a+"'")}n+="<div "+r+">"+t(e).html()+"</div>"}),"<body>"+n+"</body>"},getFormData:function(e){var n=e.clone(),o=t("input,select,textarea",n);return t("input,select,textarea",e).each(function(e){var n=t(this).attr("type");"undefined"===t.type(n)&&(n=t(this).is("select")?"select":t(this).is("textarea")?"textarea":"");var r=o.eq(e);"radio"==n||"checkbox"==n?r.attr("checked",t(this).is(":checked")):"text"==n?r.attr("value",t(this).val()):"select"==n?t(this).find("option").each(function(e){t(this).is(":selected")&&t("option",r).eq(e).attr("selected",!0)}):"textarea"==n&&r.text(t(this).val())}),n},getPrintWindow:function(){switch(c.mode){case n:var t=new d.Iframe;return{win:t.contentWindow||t,doc:t.doc};case o:var e=new d.Popup;return{win:e,doc:e.doc}}},Iframe:function(){var e,n=c.id;try{e=document.createElement("iframe"),document.body.appendChild(e),t(e).attr({style:"border:0;position:absolute;width:0px;height:0px;right:0px;top:0px;",id:n,src:"#"+(new Date).getTime()}),e.doc=null,e.doc=e.contentDocument?e.contentDocument:e.contentWindow?e.contentWindow.document:e.document}catch(t){throw t+". iframes may not be supported in this browser."}if(null==e.doc)throw"Cannot find document.";return e},Popup:function(){var t="location=yes,statusbar=no,directories=no,menubar=no,titlebar=no,toolbar=no,dependent=no";t+=",width="+c.popWd+",height="+c.popHt,t+=",resizable=yes,screenX="+c.popX+",screenY="+c.popY+",personalbar=no,scrollbars=yes";var e=window.open("","_blank",t);return e.doc=e.document,e}}}(jQuery);

function printThis(selector,sourceSelector,targetSelector){
    var mode = 'iframe'; // popup
    var close = mode == "popup";
    var options = { mode : mode, popClose : close};
    var elToPrint=null;
    if(sourceSelector)
        {
        elToPrint=$(selector).first().clone();
        if(targetSelector)
            {
            var source_el=$(sourceSelector).first();
            target_els=elToPrint.find(targetSelector);
            target_els.each(function(i,v){
                var source_clone=source_el.clone();
                $(v).prepend(source_clone);
            });
            }
        else
            elToPrint.prepend($(sourceSelector).first().clone());
        }
    else
        elToPrint=$(selector).first()
    elToPrint.printArea(options);
}