#from django.urls import path, include
#from rest_framework import routers
from django.conf.urls import url
from . import views as api


from django.views.generic.base import RedirectView
favicon_view = RedirectView.as_view(url='/template/static/favicon.ico', permanent=True)


urlpatterns = [
	#path('', include(router.urls)),
	#path(r'favicon\.ico', favicon_view),
	url(r'^js/$', api.JSConsole.as_view(), name='js'),

	url(r'^restaurant-search/$', api.Restaurant_Search.as_view(), name='restaurant-search'),
	url(r'^login/$', api.Login.as_view(), name='login'),
	url(r'^signup/$', api.Sign_Up.as_view(), name='signup'),
	url(r'^forgot-password/$', api.Forgot_Password.as_view(), name='forgot-password'),
	url(r'^menu-request/$', api.Menu_Request.as_view(), name='menu-request'),
	url(r'^post-order/$', api.Post_Order.as_view(), name='post-order'),
]
 