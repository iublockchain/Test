from django.shortcuts import render
from rest_framework import viewsets
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK
from rest_framework.permissions import IsAuthenticated,AllowAny
from django.views.generic import TemplateView
from django.views.decorators.clickjacking import xframe_options_exempt
from django.utils.decorators import method_decorator




class JSConsole(TemplateView):
	template_name='superadmin/js_console.html'

	@method_decorator(xframe_options_exempt)
	def dispatch(self, *args, **kwargs):
		response = super(JSConsole, self).dispatch(*args, **kwargs)
		referrer=self.request.META.get('HTTP_REFERER',None)
		if referrer:
			response['X-Frame-Options'] = 'ALLOW-FROM '+referrer
		else:
			response['X-Frame-Options'] = 'sameorigin'
		return response

class Restaurant_Search(APIView):
	permission_classes=(AllowAny,)
	authentication_classes=tuple()
	
	def post(self,request):
		response_dict={'success':False}

		response_dict['success']=True
		response_dict['status']=200
		response_dict['search_result'] 	=	[ {"restaurant_name" : "Restaurant Zero","restaurant_id" : 12376861223,"address" : {"full_street" : "185 Ferry St","full_city" : "Ironbound, NJ 07102",},"restaurantDistance" : "0.8 mi","restaurantsDeliveryTime" : "15-20 min.","imageUrl" : "https://res.cloudinary.com/chopstix/image/upload/w_266,h_80,f_auto,q_auto,dpr_auto,g_auto,c_fill/placeholder/placeholder"},{"restaurant_name" : "Restaurant One","restaurant_id" : 86123,"address" : {"full_street" : "82 Ferry St","full_city" : "Ironbound, NJ 07102",},"restaurantDistance" : "0.8 mi","restaurantsDeliveryTime" : "15-20 min.","imageUrl" : "https://res.cloudinary.com/chopstix/image/upload/w_266,h_80,f_auto,q_auto,dpr_auto,g_auto,c_fill/placeholder/placeholder"},{"restaurant_name" : "Restaurant Two","restaurant_id" : 123768612123,"address" : {"full_street" : "999 Ferry St","full_city" : "Ironbound, NJ 07102",},"restaurantDistance" : "0.8 mi","restaurantsDeliveryTime" : "15-20 min.","imageUrl" : "https://res.cloudinary.com/chopstix/image/upload/w_266,h_80,f_auto,q_auto,dpr_auto,g_auto,c_fill/placeholder/placeholder"},]
		
		return Response(response_dict,HTTP_200_OK) 


class Login(APIView):
	permission_classes=(AllowAny,)
	authentication_classes=tuple()
	
	def post(self,request):
		response_dict={'success':False}

		response_dict['success']=True
		response_dict['status']=200
		response_dict['search_result'] 	= { "success" : True, "customer" : { "first_name" : "Max", "last_name" : "Cooper", "phone" : "+1 973 626-4505", "email" : "maxmawad@gmail.com", "address" : [ { "nickname" : "Home", "street" : "285 MLK Blvd", "floor" : "Apt. 2", "city" : "Newark", "state" : "New Jersey", "zipcode" : "07102" } ], "past_orders" : [ { "restaurantId" : 38913892, "restaurantName" : "La taverna", "pickup" : True, "delivery" : False, "orderItemsList" : [ { "itemId" : 1882922, "itemName" : "Strupwaffle Tortilla", "itemQuantity" : 1, "itemToppings" : [ { "toppingCategoryType" : "Size", "toppingSelected" : [ { "toppingId" : 1211412, "toppingName" : "small", "toppingNumber" : 1 }], "toppingPrice" : "$0" }, { "toppingCategoryType" : "Flavor", "toppingSelected" : [ { "toppingId" : 11341223, "toppingName" : "Watermelon", "toppingNumber" : 1 } ], "toppingPrice" : "$1.00" } ], "itemSpecialRequest" : "", "itemBasePrice" : "$17.95", "itemTotalPrice" : "$18.95" }, { "itemId" : 1883922, "itemName" : "Tsu Chicken", "itemQuantity" : 1, "itemToppings" : [ { "toppingCategoryType" : "Veggetables", "toppingSelected" : [ "corn", "broccoli" ], "toppingPrice" : "$0" }, { "toppingCategoryType" : "Size", "toppingSelected" : [ "Large" ], "toppingPrice" : "$2.00" } ], "itemSpecialRequest" : "", "itemBasePrice" : "$17.95", "itemTotalPrice" : "$19.95" } ], "total" : "$64.5", "items" : 10, "payment" : { "isCash" : False, "cardName" : "Max Cooper", "cardNumber" : "182647829098476532678902", "cardExp" : "1212", "cardCVV" : "123", "cardZipcode" : "10001", "cardTip" : "$1.99" } } ], "saved_payments" : [ { "isCash" : False, "cardName" : "Max Cooper", "cardNumber" : "182647829098476532678902", "cardExp" : "1212", "cardCVV" : "123", "cardZipcode" : "10001", "cardTip" : "$1.99" } ], "notification_settings" : { "textNotifications" : True, "emailNewsletter" : True, } } } 

		return Response(response_dict,HTTP_200_OK) 


class Sign_Up(APIView):
	permission_classes=(AllowAny,)
	authentication_classes=tuple()
	
	def post(self,request):
		response_dict={'success':False}

		response_dict['success']=True
		response_dict['status']=200
		response_dict['search_result'] 	= { "success" : True, "customer" : { "first_name" : "Max", "last_name" : "Cooper", "phone" : "+1 973 626-4505", "email" : "maxmawad@gmail.com", "address" : [ ], "past_orders" : [ ], "saved_payments" : [ ], "notification_settings" : { "textNotifications" : True, "emailNewsletter" : True, } } }
		
		return Response(response_dict,HTTP_200_OK) 


class Forgot_Password(APIView):
	permission_classes=(AllowAny,)
	authentication_classes=tuple()
	
	def post(self,request):
		response_dict={'success':False}

		response_dict['success']=True
		response_dict['status']=200
		response_dict['search_result'] 	= { "user_data" : { "emailSent" : True, "textSent" : True, } } 

		return Response(response_dict,HTTP_200_OK) 





class Menu_Request(APIView):
	permission_classes=(AllowAny,)
	authentication_classes=tuple()
	
	def post(self,request):
		response_dict={'success':False}

		response_dict['success']=True
		response_dict['status']=200
		response_dict['search_result'] 	= { "status" : 200, "restaurant_id" : 1237686123, "menu_list" : [ { "item_id" : 1882922, "item_name" : "Fountain drink", "item_toppings" : [ { "option_name" : "Size", "optionMandatory" : True, "optionsList" : [ { "option_choice_name" : "Small", "optionPrice" : "$0.00" }, { "optionChoiceName" : "Medium", "optionPrice" : "$1.00" }, { "optionChoiceName" : "Large", "optionPrice" : "$2.00" } ], }, { "optionName" : "Flavor", "optionMandatory" : True, "optionsList" : [ { "optionChoiceName" : "Orange Juice", "optionPrice" : "$0.00" }, { "optionChoiceName" : "Lemon Fanta", "optionPrice" : "$0.00" }, { "optionChoiceName" : "Coca-Cola", "optionPrice" : "$1.00" } ], }], } ], } 

		return Response(response_dict,HTTP_200_OK) 





class Post_Order(APIView):
	permission_classes=(AllowAny,)
	authentication_classes=tuple()
	
	def post(self,request):
		response_dict={'success':False}

		response_dict['success']=True
		response_dict['status']=200
		response_dict['search_result'] 	= { "status" : 200, "orderNumber" : 12376890514, "orderInformation" : { "restaurantId" : 38913892, "restaurantName" : "La taverna", "pickup" : True, "delivery" : False, "total" : "$64.5", "items" : 10, }, "customer" : { "name" : "Max", "lastName" : "Cooper", "phoneNumber" : "+1 973 626-4505", "email" : "maxmawad@gmail.com", "address" : { "street" : "285 MLK Blvd", "apt" : "Apt. 2", "city" : "Newark", "state" : "New Jersey", "zipcode" : "07102" } }, } 
		
		return Response(response_dict,HTTP_200_OK) 











