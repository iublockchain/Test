# from django.db import models
# from django.contrib.auth.models import (
#     BaseUserManager, AbstractBaseUser
# )
# import json
# from django.utils import timezone
# from phonenumber_field.modelfields import PhoneNumberField


#         ############################################
#         ############    API DB OBJECTS  ############
#         ############################################

# ##  Objects/Models for optimized storage of data
# ##
# ##  Need to implement version control
# ##
# ##


# ## Restaurant Address Model (DB)
# class RestaurantAddress(models.Model):

#     full_street = models.CharField(max_length=50, default='')
#     full_city = models.CharField(max_length=50, default='')
#     street = models.CharField(max_length=50, default='')
#     city = models.CharField(max_length=30, default='')
#     state = models.CharField(max_length=2, default='')
#     zipcode = models.CharField(max_length=10, default='')

#     def __str__(self):
#         return 'Full Address: {}, {}'.format(self.full_street, self.full_city)




# ## UserManager and User Models (DB)

# class MyUserManager(BaseUserManager):
#     def create_user(self, email, password=None):
#         """
#         Creates and saves a User with the given email, date of
#         birth and password.
#         """
#         if not email:
#             raise ValueError('Users must have an email address')

#         user = self.model(
#             email=self.normalize_email(email),
#         )

#         user.set_password(password)
#         user.save(using=self._db)
#         return user

#     def create_superuser(self, email, password):
#         """
#         Creates and saves a superuser with the given email, date of
#         birth and password.
#         """
#         user = self.create_user(
#             email,
#             password=password,
#         )
#         user.is_admin = True
#         user.save(using=self._db)
#         return user





# class MyUser(AbstractBaseUser):
#     first_name = models.CharField(max_length=50, default='')
#     last_name = models.CharField(max_length=125, default='')
#     phone = PhoneNumberField(
#         blank=True,
#         unique=True,
#     )

#     email = models.EmailField(
#         verbose_name='email address',
#         max_length=255,
#         unique=True,
#     )
#     date_of_creation = models.DateTimeField(default=timezone.now)
#     is_active = models.BooleanField(default=True)
#     is_admin = models.BooleanField(default=False)

#     objects = MyUserManager()

#     USERNAME_FIELD = 'email'
#     REQUIRED_FIELDS = []

#     def __str__(self):
#         return self.email

#     def has_perm(self, perm, obj=None):
#         "Does the user have a specific permission?"
#         # Simplest possible answer: Yes, always
#         return True

#     def has_module_perms(self, app_label):
#         "Does the user have permissions to view the app `app_label`?"
#         # Simplest possible answer: Yes, always
#         return True

#     @property
#     def is_staff(self):
#         "Is the user a member of staff?"
#         # Simplest possible answer: All admins are staff
#         return self.is_admin

# ## User Address Model (DB)

# class UserAddress(models.Model):

#     full_street = models.CharField(max_length=50, default='')
#     full_city = models.CharField(max_length=50, default='')
#     street = models.CharField(max_length=50, default='')
#     floor = models.CharField(max_length=10, blank = True)
#     city = models.CharField(max_length=30, default='')
#     state = models.CharField(max_length=2, default='')
#     zipcode = models.CharField(max_length=10, default='')

#     def __str__(self):
#         return 'Full Address: {}, {}'.format(self.full_street, self.full_city)


#         ############################################
#         ############    API REQUESTS    ############
#         ############################################

# ##  data contains all requests to API
# ##
# ##  order is  request data ("3. CartPost")
# ##
# ##  user_data is login and sign in request data ()"0. LoginRequest & 0.1 SignupRequest")
# ##
# ##  menu_request is request for menu of restaurant with matching id ("2. MenuRequest")
# ##
# ##  password in UserData should be encrypted on client side with token



# ## Data Model (Request & Response)
# class Data(models.Model):
#     data = JSON.json()

#     for order in data['order']:
#         Order.objects.create(
#             restaurant_id=order['restaurant_id'],
#             is_delivery=order['is_delivery'],
#             total=order['total'],
#             items=order['items'],
#             payment=order['payment'], ## may  need to add extra code to interprete as dictionary
#             customer=order['customer'], ## may  need to add extra code to interprete as dictionary
#             )
#     for user_data in data['user_data']:
#         UserData.objects.create(
#             first_name = user_data['first_name'],
#             last_name = user_data['last_name'],
#             phone = user_data['phone'],
#             email = user_data['email'],
#             is_active = user_data['is_active'],
#             is_admin = user_data['is_admin'],

#         )

#     order = models.ForeignKey(Order, on_delete=models.CASCADE)
#     user_data = models.ForeignKey(UserData, on_delete=models.CASCADE)
#     menu_request = models.ForeignKey(MenuRequest, on_delete=models.CASCADE)


# ## UserCreationData Model (Request)
# class UserCreationData(models.Model):
#             email = models.EmailField(
#                 verbose_name='email address',
#                 max_length=255,
#                 unique=True,
#             )
#             phone = PhoneNumberField(
#                 blank=True,
#                 unique=True,
#             )
#             password = models.CharField(max_length=100)


# ## UserData Model (Request)
# class UserData(models.Model):
#         email = models.EmailField(
#             verbose_name='email address',
#             max_length=255,
#             unique=True,
#         )
#         password = models.CharField(max_length=100)


# ## Restaurant Model (DB)
# ## Restaurant.objects.all() is the dictionary that (1. Request) searches
# class Restaurant(models.Model):
#     restaurant_name = models.CharField(max_length=100)
#     restaurant_address = models.ForeignKey(RestaurantAddress, on_delete=CASCADE) ## full_street & full_city are extracted from this




# ## MenuRequest Model (Request)
# class MenuRequest(models.Model):

#     restaurant_id = models.CharField(max_length=50)
#     is_delivery = models.BooleanField(default=True) # False indicates a pickup order



# ## MenuRequest Model (Request)
# class MenuRequest(models.Model):

#     restaurant_id = models.CharField(max_length=50)
#     is_delivery = models.BooleanField(default=True) # False indicates a pickup order


# ## Criteria Model (Request) 1. RestaurantListRequest
# ## Determines search parameters for restaurant list Response

# class Criteria(models.Model):
#     address = models.ForeignKey(UserAddress, on_delete=models.CASCADE)
#     restaurant_type = models.CharField(max_length=5)
#     is_delivery = models.BooleanField(default=True) # False indicates a pickup order












#         ############################################
#         ############    API RESPONSES   ############
#         ############################################

# ##   Response Objects/Models to API Calls
# ##
# ##
# ##
# ##
# ##

# ## Customer Model (Response) 0. Login RESPONSES
# class Customer(models.Model):
#     first_name = models.CharField(max_length=50, default='')
#     last_name = models.CharField(max_length=125, default='')
#     phone = PhoneNumberField(
#         blank=True,
#         unique=True,
#     )
#     email = models.EmailField(
#         verbose_name='email address',
#         max_length=255,
#         unique=True,
#     )
#     address = models.ForeignKey(UserAddress, on_delete=models.CASCADE)
#     past_orders = models.ForeignKey(PastOrders, on_delete=models.CASCADE)
#     saved_payments = models.ForeignKey(SavedPayments, on_delete=models.CASCADE)
#     ## Payment_set.all()  Should list all Items
#     notification_settings = models.ForeignKey(NotificationSettings, on_delete=models.CASCADE)







# ## NotificationSettings Model (Response)
# class NotificationSettings(models.Model):
#     text = models.BooleanField(default=True)
#     email = models.BooleanField(default=True)



# ## RestaurantResponseObject (Response)

# class RestaurantResponseObject(models.Model):

#     restaurant_name = models.CharField(max_length=100)
#     restaurant_id = models.CharField(max_length=50)
#     address = models.ForeignKey(RestaurantAddress, on_delete=CASCADE)
#     # restaurantDistance
#     # restaurantsDeliveryTime
#     # imageUrl


# ## Menu Model (Response)
# ## Need to add: version control by adding new Menu to Restaurant Object on every change
# class Menu(models.Model):
#     restaurant_id = models.CharField(max_length=50)
#     restaurant = models.ForeignKey(Restaurant, on_delete=CASCADE)
#     ## MenuItem_set.all()  Should list all Items


# ## MenuItem Model (Response)

# class MenuItem(models.Model):
#     item_id = models.CharField(max_length=10)
#     item_name = models.CharField(max_length=50)
#     menu = models.ForeignKey(Menu, on_delete=models.CASCADE)
#     ## ToppingItem_set.all()  Should list all Toppings

# ## ToppingItem (Response)

# class ToppingItem(models.Model):
#     option_id = models.CharField(max_length=10)
#     option_name = models.CharField(max_length=50)
#     menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE)
#     ## OptionItem_set.all() Should  list all Option

# ## OptionItem Models (Response)

# class OptionItem(models.Model):
#     option_choice_name = models.CharField(max_length=50)
#     option_choice_price = models.CharField(max_length=8)
#     is_mandatory = models.BooleanField(default=False)
#     topping_item = models.ForeignKey(ToppingItem, on_delete=models.CASCADE)
