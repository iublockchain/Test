
fuser -k -v -n tcp 8000
nohup gunicorn --bind 127.0.0.1:8000 Project.wsgi:application &

