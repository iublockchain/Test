from rest_framework import permissions
from django.conf import settings
from rest_framework.authentication import TokenAuthentication
import random, string
from django.db import models
from user.models import UserProfile,Token


class CustomTokenAuthentication(TokenAuthentication):
    model = Token


class CommonPermission(permissions.BasePermission):
	message='You are not an not authorized for this action.'
	def has_permission(self, request, view):
		if not request.user.is_authenticated:
			return False
		return self.check_perm(request,view)

	def check_perm(self, request, view):
		raise NotImplementedError('Not implemented')


class IsActiveUser(CommonPermission):
	def check_perm(self, request, view):
		return request.user.status=='ACTIVE'

class IsCustomer(CommonPermission):
	def check_perm(self, request, view):
		return request.user.user_type=='CUSTOMER'