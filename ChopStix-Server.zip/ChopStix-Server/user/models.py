from django.db import models
from django.db.models import Manager
from django.contrib.auth.models import AbstractUser,BaseUserManager
from datetime import datetime
import string
import random
from django.core.validators import RegexValidator


ORDER_TYPE_CHOICES=(
	('PICKUP','Pickup'),
	('DELIVERY','Delivery'),
	('BOTH','Both'),
)

CUISINE_CHOICES=(
'Bruneian cuisine',
'Burmese cuisine',
'Cambodian cuisine',
'Cuisine of East Timor',
'Eurasian cuisine',
'Indonesian cuisine',
'Balinese cuisine',
'Batak cuisine',
'Indonesian Chinese cuisine',
'Javanese cuisine',
'Sundanese cuisine',
'Padang food',
'Laotian cuisine',
'Macanese cuisine',
'Malay cuisine',
'Penang cuisine',
'Ipoh cuisine',
'Peranakan cuisine',
'Filipino cuisine',
'Kapampangan cuisine',
'Singaporean cuisine',
'Thai cuisine',
'Vietnamese cuisine'
)

def get_restaurant_type_choices():
	return ((c,c) for c in CUISINE_CHOICES)

class Restaurant(models.Model):
	name						=   models.CharField(max_length=255,null=False,blank=False)
	street						=   models.CharField(max_length=255,null=False,blank=False)
	floor						=   models.CharField(max_length=255,null=False,blank=False)
	city						=   models.CharField(max_length=255,null=False,blank=False)
	state						=   models.CharField(max_length=255,null=False,blank=False)
	zipcode						=   models.CharField(max_length=255,null=False,blank=False)
	lat							=   models.FloatField(null=True,blank=True)
	lng							=   models.FloatField(null=True,blank=True)
	max_delivery_distance		=	models.FloatField(null=False,blank=False,default=1,verbose_name='Maximum delivery distance')
	order_types					=	models.CharField(max_length=255,null=False,default='PICKUP',choices=ORDER_TYPE_CHOICES)
	restaurant_type				=	models.CharField(max_length=255,null=True,choices=get_restaurant_type_choices())
	image						=	models.URLField(null=False,blank=False, default = 'https://res.cloudinary.com/chopstix/image/upload/v1534191568/placeholder/placeholder.jpg')
	auto_decline				=	models.BooleanField(default=False)
	is_active	 				=   models.BooleanField(null=False,blank=True,default=True)
	created		 				=   models.DateTimeField(auto_now_add=True)
	updated		 				=   models.DateTimeField(auto_now=True)

	@property
	def full_address(self):
		return ', '.join( getattr(self,i,'') for i in ('street','floor','city','state','zipcode') )

	def __str__(self):
		return '{}, {}'.format(self.name,self.street)


USER_TYPE_CHOICES=(
('SUPER_ADMIN','Super Admin'),
('BUSINESS_ADMIN','Business Admin'),
('STAFF','Staff'),
('CUSTOMER','Customer'),
)

PROFILE_STATUS_CHOICES=(
('CREATED','CREATED'),#account created, needs email verification
('ACTIVE','ACTIVE'),# profile data filled up, account active
('BLOCKED','BLOCKED'),#blocked : wrong password attempt or any invalid activity like spamming (tickets)
('DELETED','DELETED'),#
)

phone_no_field_validators=[RegexValidator(regex=r'[0-9]{10,}')]

class CustomUserManager(BaseUserManager):

	def _create_user(self, username, password,
					 is_staff, is_superuser, **extra_fields):
		"""
		Creates and saves a User with the given username and password.
		"""
		now = datetime.now()
		if not username:
			raise ValueError('Username can\'t be empty')
		user = self.model(username=username,
						  is_staff=is_staff, is_active=True,
						  is_superuser=is_superuser, last_login=now,
						  date_joined=now, **extra_fields)
		user.set_password(password)
		user.save(using=self._db)
		return user

	def create_user(self, username, password=None, **extra_fields):
		return self._create_user(username, password, False, False,
								 **extra_fields)

	def create_superuser(self, username, password, **extra_fields):
		return self._create_user(username, password, True, True,
								 **extra_fields)

class UserProfile(AbstractUser):
	# username
	# email
	# password
	# first_name
	# last_name

	phone   					=	models.CharField(max_length=15,verbose_name='Mobile number',null=True,blank=True,
									validators=phone_no_field_validators)
	# address
	street						=   models.CharField(max_length=255,null=True,blank=False)
	floor						=   models.CharField(max_length=255,null=True,blank=False)
	city						=   models.CharField(max_length=255,null=True,blank=False)
	state						=   models.CharField(max_length=255,null=True,blank=False)
	zipcode						=   models.CharField(max_length=255,null=True,blank=False)

	restaurant					=	models.ForeignKey(Restaurant,null=True,blank=True,related_name='users')

	user_type					=	models.CharField(max_length=30,null=False,blank=True,choices=USER_TYPE_CHOICES)

	email_verified				=	models.BooleanField(default=False)
	phone_verified				=	models.BooleanField(default=False)
	
	failed_login_attempt_count	=	models.IntegerField(default=0,null=False,blank=True)
	status						=	models.CharField(max_length=50,null=False,blank=True,choices=PROFILE_STATUS_CHOICES)
	status_reason				=	models.CharField(max_length=255,null=True,blank=True,default=None)
	is_active					=	models.BooleanField(null=False,blank=True,default=True)
	created						=	models.DateTimeField(auto_now_add=True)
	updated						=	models.DateTimeField(auto_now=True)

	objects=CustomUserManager()

	def __str__(self):
		return self.first_name

	chars=string.ascii_lowercase+string.digits+string.ascii_uppercase

	def set_username(self):
		self.username=(''.join(random.choice(self.chars) for i in range(7)))
		while UserProfile.objects.filter(username=self.username).exists():
			self.username=(''.join(random.choice(self.chars) for i in range(7)))


class Token(models.Model):
	key=models.CharField(max_length=40,unique=True)
	user=models.OneToOneField(UserProfile,related_name='auth_token',on_delete=models.CASCADE, verbose_name="user",unique=True)
	created=models.DateTimeField(auto_now_add=True)
	updated=models.DateTimeField(auto_now=True)
	
	def generate_key(self):
		return ''.join(random.choice(string.ascii_lowercase+string.digits+string.ascii_uppercase) for i in range(40))
		
	def save(self,*args,**kwargs):
		if not getattr(self,'key',None):
			new_key=self.generate_key()
			while type(self).objects.filter(key=new_key).exists():
				new_key=self.generate_key()
			self.key=new_key
		return super(Token,self).save(*args,**kwargs)
	

LINK_TYPE_CHOICES=(
	('EMAIL_VERIFICATION','Email Verification'),
	# ('INVITATION','Invitation'),
	('PASSWORD_RESET','Password Reset'),
)

LINK_STATUS_CHOICES=(
	('INVALID','INVALID'),
	('VALID','VALID'),
)

class OneTimeLink(models.Model):
	key_universe=string.ascii_lowercase+string.ascii_uppercase+string.digits

	key		 	=   models.CharField(max_length=255,null=False,unique=True)
	user		=   models.ForeignKey(UserProfile,null=False,related_name='activation_links')
	status	  	=   models.CharField(max_length=50,null=False,choices=LINK_STATUS_CHOICES,default='VALID')
	link_type   =   models.CharField(max_length=50,null=False,choices=LINK_TYPE_CHOICES,default='EMAIL_VERIFICATION')
	is_active   =   models.BooleanField(null=False,blank=True,default=True)
	created	 	=   models.DateTimeField(auto_now_add=True)
	updated	 	=   models.DateTimeField(auto_now=True)

	@staticmethod
	def generate_key():
		new_key=None
		while not new_key or OneTimeLink.objects.filter(key=new_key).exists():
			new_key=''.join(random.choice(OneTimeLink.key_universe) for i in range(40))
		return new_key
	
	def save(self, *args, **kwargs):
		if not getattr(self,'key',None):
			self.key=OneTimeLink.generate_key()
		super(OneTimeLink, self).save(*args, **kwargs)

OTP_TYPE_CHOICES=(
	('ACCOUNT_VERIFICATION','Account Verification'),
	# ('INVITATION','Invitation'),
	('PASSWORD_RESET','Password Reset'),
)



class OTP(models.Model):
	key_universe=string.digits

	pin			 	=   models.CharField(null=False,max_length=15,db_index=True)
	user			=   models.ForeignKey(UserProfile,null=False,related_name='otps')
	status		  	=   models.CharField(max_length=50,null=False,choices=LINK_STATUS_CHOICES,default='VALID')
	link_type	   	=   models.CharField(max_length=50,null=False,choices=OTP_TYPE_CHOICES,default='ACCOUNT_VERIFICATION')
	is_active	   	=   models.BooleanField(null=False,blank=True,default=True)
	created		 	=   models.DateTimeField(auto_now_add=True)
	updated		 	=   models.DateTimeField(auto_now=True)

	@staticmethod
	def generate_otp():
		new_otp=None
		while not new_otp or OTP.objects.filter(pin=new_otp).exists():
			new_otp=''.join(random.choice(OTP.key_universe) for i in range(6))
		return new_otp
	
	def save(self, *args, **kwargs):
		if not getattr(self,'pin',None):
			self.pin=OTP.generate_otp()
		super(OTP, self).save(*args, **kwargs)




class CustomerAddress(models.Model):
	customer                    =   models.ForeignKey(UserProfile,null=False,blank=True)
	street						=   models.CharField(max_length=255,null=False,blank=False)
	floor						=   models.CharField(max_length=255,null=False,blank=False)
	city						=   models.CharField(max_length=255,null=False,blank=False)
	state						=   models.CharField(max_length=255,null=False,blank=False)
	zipcode						=   models.CharField(max_length=255,null=False,blank=False)
	default_for_delivery		=	models.BooleanField(default=False,blank=True)
	default_for_billing			=	models.BooleanField(default=False,blank=True)
	last_used					=	models.DateTimeField(null=True,blank=True)
	is_active	   				=   models.BooleanField(null=False,blank=True,default=True)
	created		 				=   models.DateTimeField(auto_now_add=True)
	updated		 				=   models.DateTimeField(auto_now=True)

	def __str__(self):
		return '{}, {}'.format(self.street, self.city)

	@property
	def full_address(self):
		return ', '.join( getattr(self,i,'') for i in ('street','floor','city','state','zipcode') )

