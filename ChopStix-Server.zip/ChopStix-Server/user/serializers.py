from rest_framework import serializers
from user.models import UserProfile,CustomerAddress
from Project.utils import validate_password

class SignupSerializer(serializers.ModelSerializer):
    class Meta:
        model   =   UserProfile
        fields  =   ('email','phone','password')

    def validate(self, data):
        t_data=super(SignupSerializer,self).validate(data)
        if UserProfile.objects.filter(email=t_data.get('email')).exists():
            raise serializers.ValidationError("This email already have an account")
        elif UserProfile.objects.filter(phone=t_data.get('phone')).exists():
            raise serializers.ValidationError("This phone number already have an account")
        else:
            status,msg=validate_password(t_data.get('password'))
            if not status:
                raise serializers.ValidationError(msg)
        return t_data

class CustomerAddressSerializer(serializers.ModelSerializer):
    class Meta:
        model   =   CustomerAddress
        fields  =   ('street','floor','city','state','zip_code','last_used')
