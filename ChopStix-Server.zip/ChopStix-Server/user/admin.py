from django.contrib import admin
from user.models import UserProfile,OneTimeLink,OTP,CustomerAddress,Token,Restaurant

admin.site.register(Restaurant)
admin.site.register(UserProfile)
admin.site.register(OneTimeLink)
admin.site.register(OTP)
admin.site.register(CustomerAddress)
admin.site.register(Token)