from django.conf.urls import url
from user import views as v 


urlpatterns = [
	url(r'^login/$', v.UserLogin.as_view(), name='login'),
    url(r'^logout/$', v.Logout.as_view(), name='logout'),
    url(r'^change-password/$', v.ChangePassword.as_view(), name='change-password'),
	url(r'^signup/$', v.Signup.as_view(), name='signup'),
	url(r'^verify-email/(?P<key>[a-zA-Z0-9]{40})/$', v.VerifyEmail.as_view(), name='verify-email'),
	url(r'^verify-otp/$', v.VerifyOTP.as_view(), name='verify-otp'),
	url(r'^forgot-password/$', v.RequestPasswordReset.as_view(), name='forgot-password'),
	url(r'^reset-password/(?P<key>[a-zA-Z0-9]{40})/$', v.ResetPassword.as_view(), name='reset-password'),
	url(r'^customer-login/$', v.CustomerLogin.as_view(), name='customer-login'),
	 
	


]