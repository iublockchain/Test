from django import forms
from user.models import UserProfile
from Project.utils import validate_password

class LoginForm(forms.ModelForm):
    class Meta:
        model=UserProfile
        fields=('email','password')
        widgets={'password':forms.PasswordInput()}

class PasswordResetForm(forms.Form):
    password            =   forms.CharField(widget=forms.PasswordInput(),required=True)
    confirm_password    =   forms.CharField(widget=forms.PasswordInput(),required=True)

    def clean(self,*args,**kwargs):
        c_data=super(PasswordResetForm,self).clean(*args,**kwargs)
        pwd=c_data.get('password')
        c_pwd=c_data.get('confirm_password')
        if pwd!=c_pwd:
            self.add_error('confirm_password','Passwords do not match')
        else:
            stat,msg=validate_password(pwd)
            if not stat:
                self.add_error('password',msg)
        return c_data