from django.shortcuts import render,redirect
from django.template.loader import render_to_string
from user.models import UserProfile,Token,OTP,OneTimeLink,Token
from django.views.generic import View,TemplateView
from django.contrib import messages
from django.contrib.auth import login,logout
from django.conf import settings
from Project.utils import validate_password,get_error,utc_now
from user.forms import LoginForm,PasswordResetForm
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated,AllowAny
from user.api_permissions import CustomTokenAuthentication,IsActiveUser,IsCustomer
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK
from user.serializers import SignupSerializer,CustomerAddressSerializer
from communications.models import SMS,Email
from django.http import HttpResponse
from datetime import timedelta
from restaurant.serializers import CustomerSerializer,OrderSerializer
from restaurant.models import Order
from user.models import CustomerAddress
from django.contrib.auth.mixins import LoginRequiredMixin


# ================================
# WEB
# ================================
class UserLogin(TemplateView):
	template_name='public/login.html'
	blocked_msg='This account has been blocked. Please contact admin.'
	invalid_cred_msg='Invalid credentials'
	no_account_msg='Invalid credentials'
	def get_context_data(self,*args,**kwargs):
		context = super(UserLogin, self).get_context_data(**kwargs)
		context['form']=LoginForm()
		return context

	def post(self,request):
		form=LoginForm(request.POST)
		context={'form':form}
		email=request.POST.get('email')
		password=request.POST.get('password')
		user=UserProfile.objects.filter(email=email).first()
		if not user:
			form.add_error('email',self.no_account_msg)
			return render(request,self.template_name,context)
		if not user.check_password(password):
			form.add_error('email',self.invalid_cred_msg)
			return render(request,self.template_name,context)
		login(request,user)
		if user.user_type == 'SUPER_ADMIN':
			return redirect('superadmin:list-restaurants')
		elif user.user_type=='BUSINESS_ADMIN':
			return redirect('restaurant:list-products')


class Logout(View):
	def get(self,request):
		logout(request)
		return redirect('/')

class ChangePassword(LoginRequiredMixin,View):
	def post(self,request):
		redirect_url=request.GET.get('return')
		new_password=request.POST.get('new_password')
		res,msg=validate_password(new_password)
		if not res:
			messages.error(request,msg)
		else:
			user=request.user
			if not user.check_password(request.POST.get('old_password')):
				messages.error(request,'Old password entered is incorrect')
			else:
				user.set_password(new_password)
				user.save()
				messages.error(request,'Password changed successfully')
		return redirect(redirect_url)


class VerifyEmail(View):
	def get(self,request,key):
		link=OneTimeLink.objects.filter(key=key,is_active=True,status='VALID',
			link_type='EMAIL_VERIFICATION').select_related('user').first()
		if not link:
			return HttpResponse('<h3>Invalid link</h3>')
		if link.created+timedelta(hours=2)<utc_now().replace(tzinfo=None):
			return HttpResponse('<h3>Link expired</h3>')
		user=link.user
		user.email_verified=True
		link.status='INVALID'
		user.save()
		link.save()
		messages.success(request,'Email verified successfully')
		return redirect('/')

class ResetPassword(View):
	template_name='public/reset_password.html'
	def get(self,request,key):
		link=OneTimeLink.objects.filter(key=key,is_active=True,status='VALID',
			link_type='PASSWORD_RESET').select_related('user').first()
		if not link:
			return HttpResponse('<h3>Invalid link</h3>')
		if link.created+timedelta(hours=2)<utc_now().replace(tzinfo=None):
			return HttpResponse('<h3>Link expired</h3>')
		form=PasswordResetForm()
		return render(request,self.template_name,{'form':form})

	def post(self,request,key):
		link=OneTimeLink.objects.filter(key=key,is_active=True,status='VALID',
			link_type='PASSWORD_RESET').select_related('user').first()
		if not link:
			return HttpResponse('<h3>Invalid link</h3>')
		if link.created+timedelta(hours=2)<utc_now().replace(tzinfo=None):
			return HttpResponse('<h3>Link expired</h3>')
		form=PasswordResetForm(request.POST)
		if form.is_valid():
			user=link.user
			user.set_password(form.cleaned_data.get('password'))
			link.status='INVALID'
			user.save()
			link.save()
			messages.success(request,'Password reset successfully')
			return redirect('/')
		else:
			return render(request,self.template_name,{'form':form})

# ================================
# API
# ================================
class Signup(APIView):
	permission_classes=(AllowAny,)
	authentication_classes=tuple()
	
	def post(self,request):
		response_dict={'success':False}
		user_data=request.data.get('user_data',{})
		serializer=SignupSerializer(data=user_data)
		if serializer.is_valid():
			u_data=serializer.validated_data
			customer=UserProfile(user_type='CUSTOMER',status='CREATED',**u_data)
			customer.set_username()
			customer.set_password(user_data.get('password'))
			customer.save()

			otp=OTP.objects.create(user=customer,link_type='ACCOUNT_VERIFICATION')
			sms_context={'otp':otp.pin}
			message=render_to_string('otp_template.html',sms_context)
			sms_count=int(len(message)/140)+(1 if len(message)%140 > 0 else 0)
			sms=SMS.objects.create(is_system_generated=True,message=message,
				sms_count=sms_count,mobile_no=customer.phone)
			otl=OneTimeLink.objects.create(user=customer,link_type='EMAIL_VERIFICATION')
			email_context={'settings':settings,'otl':otl}
			message=render_to_string('verification_email_template.html',email_context)
			email=Email.objects.create(to=u_data.get('email'),subject='Chopstix Email Verification',content=message)
			response_dict['emailSent']=True
			response_dict['textSent']=True
			response_dict['success']=True
			return Response(response_dict,HTTP_200_OK)
		else:
			response_dict['reason']=get_error(serializer)
			return Response(response_dict,HTTP_200_OK)


class VerifyOTP(APIView):
	permission_classes=(AllowAny,)
	authentication_classes=tuple()
	
	def post(self,request):
		response_dict={'success':False}
		otp=request.data.get('otp')
		phone=request.data.get('phone')
		otp=OTP.objects.filter(pin=otp,user__phone=phone,link_type='ACCOUNT_VERIFICATION',
			is_active=True,status='VALID').select_related('user').first()
		if not otp:
			response_dict['reason']='Wrong OTP'
			return Response(response_dict,HTTP_200_OK)
		if otp.created+timedelta(minutes=4)<utc_now().replace(tzinfo=None):
			response_dict['reason']='OTP expired'
			return Response(response_dict,HTTP_200_OK)
		user=otp.user
		user.phone_verified=True
		otp.status='INVALID'
		user.save()
		otp.save()
		UserProfile.objects.filter(phone_verified=True,status='CREATED').update(status='ACTIVE')
		response_dict['success']=True
		return Response(response_dict,HTTP_200_OK)



class RequestPasswordReset(APIView):
	permission_classes=(AllowAny,)
	authentication_classes=tuple()
	
	def post(self,request):
		response_dict={'success':False,'textSent':False,'emailSent':False}
		user_data=request.data.get('user_data',{})
		email=user_data.get('email')
		phone=user_data.get('phoneNumber')
		if not (email or phone):
			response_dict['reason']='Email or phone number is mandatory'
			return Response(response_dict,HTTP_200_OK)
		if email:
			email_customer=UserProfile.objects.filter(user_type='CUSTOMER',email=email,is_active=True,
				email_verified=True,status='ACTIVE').first()
		if phone:
			phone_customer=UserProfile.objects.filter(user_type='CUSTOMER',phone=phone,is_active=True,
				phone_verified=True,status='ACTIVE').first()
		if not (email_customer or phone_customer):
			response_dict['reason']='An account with given Email or phone number cannot be found'
			return Response(response_dict,HTTP_200_OK)
		if all((email, phone, email_customer, phone_customer)) and email_customer.id!=phone_customer.id:
			response_dict['reason']='Email and phone number are associated with two different accounts'
			return Response(response_dict,HTTP_200_OK)

		customer=email_customer or phone_customer
		otl=OneTimeLink.objects.create(user=customer,link_type='PASSWORD_RESET')
		
		if phone_customer:
			sms_context={'otl':otl,'settings':settings}
			message=render_to_string('password_reset_sms.html',sms_context)
			sms_count=int(len(message)/140)+(1 if len(message)%140 > 0 else 0)
			sms=SMS.objects.create(is_system_generated=True,message=message,
				sms_count=sms_count,mobile_no=customer.phone)
			response_dict['textSent']=True
		if email_customer:
			email_context={'settings':settings,'otl':otl}
			message=render_to_string('password_reset_email.html',email_context)
			email=Email.objects.create(to=customer.email,subject='Chopstix Password Reset',content=message)
			response_dict['emailSent']=True
		response_dict['success']=True
		return Response(response_dict,HTTP_200_OK)


class CustomerLogin(APIView):
	permission_classes=(AllowAny,)
	authentication_classes=tuple()
	
	def post(self,request):
		response_dict={'success':False}
		user_data=request.data.get('user_data',{})
		email=user_data.get('email')
		if not email:
			response_dict['reason']='Email cannot be empty'
			return Response(response_dict,HTTP_200_OK)
		customer=UserProfile.objects.filter(user_type='CUSTOMER',email=email).first()
		if not customer:
			response_dict['reason']='Unknown account'
			return Response(response_dict,HTTP_200_OK)
		if not customer.check_password(user_data.get('password')):
			response_dict['reason']='Invalid credentials'
			return Response(response_dict,HTTP_200_OK)
		token,c=Token.objects.get_or_create(user=customer)
		response_dict['token']=token.key
		response_dict['customer']=CustomerSerializer(customer).data
		past_orders=Order.objects.filter(customer=customer).prefetch_related('order_items')
		response_dict['past_orders']=OrderSerializer(past_orders,many=True).data
		customer_addresses=CustomerAddress.objects.filter(customer=customer,is_active=True
			).order_by('-last_used')
		response_dict['customer']['addresses']=CustomerAddressSerializer(customer_addresses,many=True).data
		response_dict['customer']['default_address']=None
		if customer_addresses:
			response_dict['customer']['default_address']=CustomerAddressSerializer(customer_addresses[0]).data	
		

		
		# Include notification settings
		response_dict['success']=True
		response_dict['status']=200
		
		return Response(response_dict,HTTP_200_OK)
		

	# 	permission_classes=(IsActiveUser,IsAuthenticated,)
	# authentication_classes=(CustomTokenAuthentication,)

# login response

# {
#     "status" : 200,
#     "customer" : {
#         "first_name" : "Max",
#         "last_name" : "Cooper",
#         "phone" : "+1 973 626-4505",
#         "email" : "maxmawad@gmail.com",
#         "address" : {
#             "street" : "285 MLK Blvd",
#             "floor" : "Apt. 2",
#             "city" : "Newark",
#             "state" : "New Jersey",
#             "zipcode" : "07102"
#         },
#         "past_orders" : [
#             {
#         "restaurantId" : 38913892,
#         "restaurantName" : "La taverna",
#         "pickup" : true,
#         "delivery" : false,
#         "orderItemsList" : [
#       {
#           "itemId" : 1882922,
#           "itemName" : "Strupwaffle Tortilla",
#           "itemQuantity" : 1,
#           "itemToppings" : [
#               {
#                   "toppingCategoryType" : "Size",
#                   "toppingSelected" : [ {
#                       "toppingId" : 1211412,
#                       "toppingName" : "small",
#                       "toppingNumber" : 1
#                   }],
#                   "toppingPrice" : "$0"
#               },
#               {
#                   "toppingCategoryType" : "Flavor",
#                   "toppingSelected" : [ {
#                       "toppingId" : 11341223,
#                       "toppingName" : "Watermelon",
#                       "toppingNumber" : 1
#                   } ],
#                   "toppingPrice" : "$1.00"
#               }   
#           ],
#           "itemSpecialRequest" : "",
#           "itemBasePrice" : "$17.95",
#           "itemTotalPrice" : "$18.95"
#       },
#       {
#           "itemId" : 1883922,
#           "itemName" : "Tsu Chicken",
#           "itemQuantity" : 1,
#           "itemToppings" : [
#               {
#                   "toppingCategoryType" : "Veggetables",
#                   "toppingSelected" : [ "corn", "broccoli" ],
#                   "toppingPrice" : "$0"
#               },
#               {
#                   "toppingCategoryType" : "Size",
#                   "toppingSelected" : [ "Large" ],
#                   "toppingPrice" : "$2.00"
#               }   
#           ],
#           "itemSpecialRequest" : "",
#           "itemBasePrice" : "$17.95",
#           "itemTotalPrice" : "$19.95"
#       }
#   ],
#         "total" : "$64.5",
#         "items" : 10,
#         "payment" : {
#             "isCash" : false,
#             "cardName" : "Max Cooper",
#             "cardNumber" : "182647829098476532678902",
#             "cardExp" : "1212",
#             "cardCVV" : "123",
#             "cardZipcode" : "10001",
#             "cardTip" : "$1.99"
#     }
#     }
#         ],
#         "saved_payments" : [
#             {
#             "isCash" : false,
#             "cardName" : "Max Cooper",
#             "cardNumber" : "182647829098476532678902",
#             "cardExp" : "1212",
#             "cardCVV" : "123",
#             "cardZipcode" : "10001",
#             "cardTip" : "$1.99"
#     }
#         ],
#         "notification_settings" : {
#             "textNotifications" : true,
#             "emailNewsletter" : true,
            
#         }
#         }
# }