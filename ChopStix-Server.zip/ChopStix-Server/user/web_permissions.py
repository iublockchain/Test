from django.contrib.auth.mixins import AccessMixin
from django.urls import reverse
from django.conf import settings
from django.shortcuts import redirect
from django.contrib import messages

class UserTypeTestMixin(AccessMixin):
    user_type=None
    session_data=None

    user_type_home_page={
        'SUPER_ADMIN':'superadmin:list-restaurants',
        'BUSINESS_ADMIN':'restaurant:list-products',
        'CUSTOMER':'website:index',
        }
    permission_denied_message='You are not allowed there!'

    def test_func(self):
        raise NotImplementedError(
            '{0} is missing the implementation of the test_func() method.'.format(self.__class__.__name__)
        )

    def get_login_url(self):
        login_url = self.login_url or settings.LOGIN_URL
        if not self.request.user.is_authenticated:
            return login_url
        else:
            return reverse(self.user_type_home_page[self.request.user.user_type])

    def dispatch(self, request, *args, **kwargs):
        self.request=request
        if not request.user.is_authenticated:
            return self.handle_no_permission()
        self.user_type=request.user.user_type
        user_test_result = self.test_func()
        if not user_test_result:
            messages.error(request,'You are not allowed here')
            return self.handle_no_permission()
        return super(UserTypeTestMixin, self).dispatch(request, *args, **kwargs)


class IsSuperAdminMixin(UserTypeTestMixin):
    def test_func(self):
        return self.user_type=='SUPER_ADMIN'

class IsRestaurantAdminMixin(UserTypeTestMixin):
    def test_func(self):
        return self.user_type=='BUSINESS_ADMIN'

class IsCustomerMixin(UserTypeTestMixin):
    def test_func(self):
        return self.user_type=='CUSTOMER'

