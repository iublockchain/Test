from django.conf.urls import url, include
from restaurant import views as v

urlpatterns = [
    
    # For restaurant admin
    url(r'^products/$', v.ListProducts.as_view(), name='list-products'),
    url(r'^add-product/$', v.AddProduct.as_view(), name='add-product'),
	url(r'^edit-product/(?P<pk>\d+)/$',v.EditProduct.as_view(),name='edit-product'),
    url(r'^delete-product/(?P<pk>\d+)/$',v.DeleteProduct.as_view(),name='delete-product'),

    url(r'^variant-types/(?P<pk>\d+)/$',v.ListVariantTypes.as_view(),name='list-variant-types'),
    url(r'^add-variant-type/(?P<pk>\d+)/$',v.AddVariantType.as_view(),name='add-variant-type'),
    url(r'^edit-variant-type/(?P<pk>\d+)/$',v.EditVariantType.as_view(),name='edit-variant-type'),
    url(r'^delete-variant-type/(?P<pk>\d+)/$',v.DeleteVariantType.as_view(),name='delete-variant-type'),

    url(r'^variants/(?P<pk>\d+)/$',v.ListVariants.as_view(),name='list-variants'),
    url(r'^edit-variant/(?P<pk>\d+)/$',v.EditVariant.as_view(),name='edit-variant'),
    url(r'^delete-variant/(?P<pk>\d+)/$',v.DeleteVariant.as_view(),name='delete-variant'),
    url(r'^set-price-of-variants/(?P<pk>\d+)/$',v.SetPriceOfVariants.as_view(),name='set-price-of-variants'),
    url(r'^get-price/(?P<pk>\d+)/$',v.GetPrice.as_view(),name='get-price'),
    url(r'^orders/$', v.ListOrders.as_view(), name='list-orders'),
    url(r'^order-details/(?P<pk>\d+)/$', v.OrderDetails.as_view(), name='order-details'),
    url(r'^mark-delivered/(?P<pk>\d+)/$', v.MarkDelivered.as_view(), name='mark-delivered'),
    url(r'^decline-order/(?P<pk>\d+)/$', v.DeclineOrder.as_view(), name='decline-order'),
    url(r'^toggle-auto-decline/$', v.ToggleAutoDecline.as_view(), name='toggle-auto-decline'),

    
    
    

    # API for the Public
    url(r'^find/$',v.FindRestaurant.as_view(),name='find'),
    url(r'^get-menu/$',v.GetMenu.as_view(),name='get-menu'),
    url(r'^get-price/$',v.GetPriceOfSelection.as_view(),name='get-price'),
    url(r'^place-order/$',v.PlaceOrder.as_view(),name='place-order'),
    
    

]
