from rest_framework import serializers
from user.models import UserProfile,CustomerAddress
from restaurant.models import Order,OrderItem,Product,Variant,VariantType,PaymentMethod
import re
from datetime import datetime
import calendar


class CustomerSerializer(serializers.ModelSerializer):
    class Meta:
        model   =   UserProfile
        fields  =   ('id','first_name','last_name','email','phone')
        # 'street','floor','city','state','zipcode')

    # def to_representation(self,obj,*args,**kwargs):
    #     t_dict=super(CustomerSerializer,self).to_representation(obj,*args,**kwargs)
    #     t_dict['address']={}
    #     for key in ('street','floor','city','state','zipcode'):
    #         t_dict['address'][key]=t_dict.pop(key,None)
    #     return t_dict


class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model   =   Product
        fields  =   ('id','name','base_price','image','is_pick_up_only')

class VariantTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model   =   VariantType
        fields  =   ('id','name','category','required','is_addon','allow_multiple')


class VariantSerializerLite(serializers.ModelSerializer):
    class Meta:
        model   =   Variant
        fields  =   ('id','name','price')
        # @TODO : remove price if varaint_type.is_addon != True


class VariantSerializer(serializers.ModelSerializer):
    variant_type=VariantTypeSerializer()
    class Meta:
        model   =   Variant
        fields  =   ('id','variant_type','name','price')
        # @TODO : remove price if varaint_type.is_addon != True

class PaymentMethodSerializer(serializers.ModelSerializer):
    cardno_regex=r'^(?:4[0-9]{12}(?:[0-9]{3})?|[25][1-7][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})\Z'
    class Meta:
        model   =   PaymentMethod
        fields  =   ('id','card_name','card_number','card_expiry','card_cvv','zip_code')
        read_only_fields=('id',)
    
    def validate(self,data):
        tdata=super(PaymentMethodSerializer,self).validate(data)
        card_number=tdata.get('card_number')
        result=re.match(self.cardno_regex,card_number)
        if result is None:
            raise serializers.ValidationError("Invalid card number")
        card_expiry=tdata.get('card_expiry')
        mm=int(card_expiry[0:2])
        yy=int(card_expiry[2:])
        if not card_expiry.isdigit() or len(card_expiry)!=4 or mm<1 or mm>12:
            raise serializers.ValidationError("invalid card expiry ")
        today=datetime.now().date()
        max_day=calendar.monthrange(int('20'+str(yy)),int(mm))[1]
        expiry_date=datetime.strptime('20'+str(yy)+'-'+str(mm)+'-'+str(max_day),'%Y-%m-%d').date()
        if today>expiry_date:
            raise serializers.ValidationError("Card already expired")
        card_cvv=tdata.get('card_cvv')
        if not card_cvv.isdigit() or len(card_cvv) not in (3,4):
            raise serializers.ValidationError("Invalid CVV")
        return tdata
        





class OrderItemSerializer(serializers.ModelSerializer):
    product=ProductSerializer()
    variants=VariantSerializer(many=True)
    class Meta:
        model   =   OrderItem
        fields  =   ('id','product','variants','quantity','total_price')


class OrderSerializer(serializers.ModelSerializer):
    order_items=OrderItemSerializer(many=True)
    payment_method=PaymentMethodSerializer()
    class Meta:
        model   =   Order
        fields  =   ('id','order_type','total','order_items','payment_method')

class CustomerAddressSerializer(serializers.ModelSerializer):
    class Meta:
        model   =   CustomerAddress
        fields  =   ('id','street','floor','city','state','zipcode')
        read_only_fields=('id',)
