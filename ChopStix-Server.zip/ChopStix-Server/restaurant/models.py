from django.db import models
from user.models import UserProfile,Restaurant,CustomerAddress
from datetime import datetime

# superadmin only
class ProductTag(models.Model):
	tag						 	= models.CharField(max_length=255,null=False,blank=False)
	is_active	   				=   models.BooleanField(null=False,blank=True,default=True)
	created		 				=   models.DateTimeField(auto_now_add=True)
	updated		 				=   models.DateTimeField(auto_now=True)


class Product(models.Model):
	restaurant				 	=   models.ForeignKey(Restaurant,null=False,blank=True,db_index=True)
	name						=   models.CharField(max_length=255,null=False,blank=False)
	level1					 	=   models.CharField(max_length=255,null=False,blank=False)
	level2					 	=   models.CharField(max_length=255,null=True,blank=True)
	level3					 	=   models.CharField(max_length=255,null=True,blank=True)
	tags						=   models.ManyToManyField(ProductTag)
	base_price				 	=   models.FloatField(null=True,blank=False)
	image						=	models.ImageField(null=False,blank=False)
	is_pick_up_only				=	models.BooleanField(null=False,blank=True,default=False)
	is_active	 				=   models.BooleanField(null=False,blank=True,default=True)
	created		 				=   models.DateTimeField(auto_now_add=True)
	updated		 				=   models.DateTimeField(auto_now=True)

class VariantType(models.Model):
	restaurant				 	=   models.ForeignKey(Restaurant,null=False,blank=True,db_index=True)
	product						=   models.ForeignKey(Product,null=False,blank=True,related_name='variant_types',db_index=True)
	name						=   models.CharField(max_length=255,null=False,blank=False)
	category					=   models.CharField(max_length=255,null=True,blank=True)#optional for future use
	required					=   models.BooleanField(default=False,blank=True)
	is_addon					=   models.BooleanField(default=False,blank=True)
	# allow_multiple can be True only if is_addon is True
	allow_multiple			 	=   models.BooleanField(default=False,blank=True)
	is_active	 				=   models.BooleanField(null=False,blank=True,default=True)
	created		 				=   models.DateTimeField(auto_now_add=True)
	updated		 				=   models.DateTimeField(auto_now=True)

class Variant(models.Model):
	restaurant				 	=   models.ForeignKey(Restaurant,null=False,blank=True,db_index=True)
	product						=   models.ForeignKey(Product,null=False,blank=True,related_name='variants',db_index=True)
	variant_type				=   models.ForeignKey(VariantType,null=False,blank=True,related_name='variants',db_index=True)
	name						=   models.CharField(max_length=255,null=False,blank=False)
	# price is relevent only for addons
	price					  	=   models.FloatField(null=True,blank=False)
	is_active	 				=   models.BooleanField(null=False,blank=True,default=True)
	created		 				=   models.DateTimeField(auto_now_add=True)
	updated		 				=   models.DateTimeField(auto_now=True)

class VariantPricing(models.Model):
	restaurant				 	=   models.ForeignKey(Restaurant,null=False,blank=True,db_index=True)
	product						=   models.ForeignKey(Product,null=False,blank=True,related_name='variant_prices',db_index=True)
	variants					=   models.ManyToManyField(Variant)
	# price for above combination
	price					  	=   models.FloatField(null=False,blank=False)
	is_active	 				=   models.BooleanField(null=False,blank=True,default=True)
	created		 				=   models.DateTimeField(auto_now_add=True)
	updated		 				=   models.DateTimeField(auto_now=True)


ORDER_TYPE_CHOICES=(
	('PICKUP','Pickup'),
	('DELIVERY','Delivery'),
)

class PaymentMethod(models.Model):
	customer					=   models.ForeignKey(UserProfile,null=False,blank=True,db_index=True)
	card_name				  	=   models.CharField(max_length=255,null=False,blank=False)
	card_number					=   models.CharField(max_length=255,null=False,blank=False)
	card_expiry					=   models.CharField(max_length=255,null=False,blank=False)#mmyy
	card_cvv					=   models.CharField(max_length=255,null=False,blank=False)
	zip_code					=   models.CharField(max_length=255,null=False,blank=False)


class Cart(models.Model):
	session_id					=   models.CharField(null=False,blank=False,max_length=255,db_index=True)
	restaurant				 	=   models.ForeignKey(Restaurant,null=False,blank=True)
		
class CartItem(models.Model):
	restaurant				 	=   models.ForeignKey(Restaurant,null=False,blank=True,db_index=True)
	cart					  	=   models.ForeignKey(Cart,null=False,blank=True,db_index=True,related_name='cart_items')
	product						=   models.ForeignKey(Product,null=False,blank=True)
	variants					=   models.ManyToManyField(Variant)
	quantity					=   models.FloatField(null=False,blank=False)
	item_price					=   models.FloatField(null=False,blank=False)#product price + prices of toppings



PROMO_CODE_TYPES=(
	('FLAT_PERCENTAGE_DISCOUNT','Flat Discount in percentage'),
	('FIXED_DISCOUNT','Fixed amount discount'),
)

class PromoCode(models.Model):
	restaurants				 	=   models.ManyToManyField(Restaurant,blank=True)
	all_restaurants				=	models.BooleanField(null=False,blank=True,default=False)
	customers					=   models.ManyToManyField(UserProfile,blank=True)
	all_customers				=	models.BooleanField(null=False,blank=True,default=False)
	max_usage					=	models.IntegerField(null=False,blank=False,default=1,verbose_name='Maximum no of usage per customer')
	valid_from					=	models.DateField(null=False,blank=False,default=datetime.now)
	valid_till					=	models.DateField(null=False,blank=False)
	promo_type					=	models.CharField(max_length=255,null=False,blank=False,choices=PROMO_CODE_TYPES)
	min_order_amount			=	models.FloatField(null=False,blank=False)
	code						=	models.CharField(max_length=255,null=False,blank=False,db_index=True)
	discount					=	models.FloatField(null=False,blank=False)#can be % or amount
	is_active	 				=   models.BooleanField(null=False,blank=True,default=True)
	created		 				=   models.DateTimeField(auto_now_add=True)
	updated		 				=   models.DateTimeField(auto_now=True)

class PromoCodeUsage(models.Model):
	promo_code				 	=   models.ForeignKey(PromoCode,null=False,blank=True)
	customer					=   models.ForeignKey(UserProfile,null=False,blank=True)
	usage_count					=   models.IntegerField(null=False,blank=False)

class Order(models.Model):
	restaurant				 	=   models.ForeignKey(Restaurant,null=False,blank=True,db_index=True)
	customer					=   models.ForeignKey(UserProfile,null=False,blank=True,db_index=True)
	order_type				 	=   models.CharField(max_length=200,blank=True,null=False,
										choices=ORDER_TYPE_CHOICES)
	customer_address			=	models.ForeignKey(CustomerAddress,null=True,blank=True)
	is_cash						=	models.BooleanField(default=True)
	payment_method				=	models.ForeignKey(PaymentMethod,null=True,blank=True)
	card_tip					=	models.FloatField(null=True,blank=True)
	promo_code					=	models.ForeignKey(PromoCode,null=True,blank=True)
	total						=	models.FloatField(null=False,blank=False,default=0)
	discount					=	models.FloatField(null=False,blank=True,default=0)
	amount_payable				=	models.FloatField(null=False,blank=False)
	paid						=	models.BooleanField(default=False)
	schedule					=   models.DateTimeField(null=True,blank=True)
	declined					=	models.BooleanField(null=False,default=False)
	delivered					=	models.BooleanField(null=False,default=False)
	is_active	 				=   models.BooleanField(null=False,blank=True,default=True)
	created		 				=   models.DateTimeField(auto_now_add=True)
	updated		 				=   models.DateTimeField(auto_now=True)

	


class OrderItem(models.Model):
	restaurant				 	=   models.ForeignKey(Restaurant,null=False,blank=True,db_index=True)
	order					  	=   models.ForeignKey(Order,null=False,blank=True,db_index=True,related_name='order_items')
	customer					=   models.ForeignKey(UserProfile,null=False,blank=True)
	product						=   models.ForeignKey(Product,null=False,blank=True)
	variants					=   models.ManyToManyField(Variant)
	quantity					=   models.FloatField(null=False,blank=False)
	total_price					=   models.FloatField(null=False,blank=False)#product price + prices of toppings
	is_active	 				=   models.BooleanField(null=False,blank=True,default=True)
	created		 				=   models.DateTimeField(auto_now_add=True)
	updated		 				=   models.DateTimeField(auto_now=True)



class GeoCodeCache(models.Model):
	address						=	models.CharField(max_length=255,null=False,blank=False)
	state						=	models.CharField(max_length=255,null=False,blank=False,db_index=True)
	city						=	models.CharField(max_length=255,null=False,blank=False,db_index=True)
	lat							=	models.FloatField(null=False)
	lng							=	models.FloatField(null=False)
	access_count				=	models.IntegerField(null=False,default=1)
	last_access					=	models.DateTimeField(null=False,default=datetime.now)

