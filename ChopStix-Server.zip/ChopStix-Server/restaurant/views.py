from django.shortcuts import render,redirect
from user.models import UserProfile,CustomerAddress
from restaurant.models import Restaurant,Product,VariantType,Variant,VariantPricing,GeoCodeCache,Order,\
	OrderItem,PaymentMethod,PromoCode,PromoCodeUsage
from restaurant.forms import RestaurantForm,RestaurantAdminForm,ProductForm,VariantTypeForm,VariantForm
from django.views.generic import View,TemplateView,ListView
from django.http import Http404,JsonResponse
from django.contrib import messages
from django.db.models import Prefetch,Q,Count,Sum
from django.db import transaction
from Project.utils import get_error,geocode
from user.web_permissions import IsRestaurantAdminMixin
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated,AllowAny
from user.api_permissions import CustomTokenAuthentication,IsActiveUser,IsCustomer
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK
from django.conf import settings
import math
from restaurant.serializers import ProductSerializer,VariantTypeSerializer,CustomerAddressSerializer,\
	PaymentMethodSerializer
from datetime import datetime,timedelta


class ListProducts(IsRestaurantAdminMixin,ListView):
	template_name='admin/list_products.html'
	def get_queryset(self,*args,**kwargs):
		return Product.objects.filter(restaurant=self.request.user.restaurant,is_active=True)

class AddProduct(IsRestaurantAdminMixin,TemplateView):
	template_name='admin/add_product.html'
	def get_context_data(self,*args,**kwargs):
		context=super(AddProduct,self).get_context_data(*args,**kwargs)
		context['form']=ProductForm()
		return context

	def post(self,request):
		form=ProductForm(request.POST,request.FILES)
		if form.is_valid():
			prod=form.save(commit=False)
			prod.restaurant=request.user.restaurant
			prod.save()
			return redirect('restaurant:list-products')
		context={'form':form,}
		return render(request,self.template_name,context)


class EditProduct(IsRestaurantAdminMixin,TemplateView):
	template_name='admin/edit_product.html'
	def get_context_data(self,*args,**kwargs):
		pk=self.kwargs.get('pk')
		context=super(EditProduct,self).get_context_data(*args,**kwargs)
		product=Product.objects.filter(restaurant=self.request.user.restaurant,pk=pk).first()
		if not product:
			raise Http404
		context['form']=ProductForm(instance=product)
		return context

	def post(self,request,pk,*args,**kwargs):
		product=Product.objects.filter(restaurant=request.user.restaurant,pk=pk).first()
		if not product:
			raise Http404
		form=ProductForm(request.POST,request.FILES,instance=product)
		if form.is_valid():
			form.save()
			return redirect('restaurant:list-products')
		context={'form':form}
		return render(request,self.template_name,context)


class DeleteProduct(IsRestaurantAdminMixin,View):
	def post(self,request,pk,*args,**kwargs):
		Product.objects.filter(restaurant=request.user.restaurant,id=pk).update(is_active=False)
		messages.error(request,'product deleted')
		return redirect('restaurant:list-products')



class ListVariantTypes(IsRestaurantAdminMixin,ListView):
	template_name='admin/list_variant_types.html'
	def get_queryset(self,*args,**kwargs):
		pk=self.kwargs.get('pk')
		return VariantType.objects.filter(restaurant=self.request.user.restaurant,product__id=pk,is_active=True)
	
	def get_context_data(self,*args,**kwargs):
		context=super(ListVariantTypes,self).get_context_data(*args,**kwargs)
		pk=self.kwargs.get('pk')
		product=Product.objects.filter(restaurant=self.request.user.restaurant,id=pk,is_active=True).first()
		context['product']=product
		return context

class AddVariantType(IsRestaurantAdminMixin,TemplateView):
	template_name='admin/add_variant_type.html'
	def get_context_data(self,*args,**kwargs):
		context=super(AddVariantType,self).get_context_data(*args,**kwargs)
		pk=self.kwargs.get('pk')
		product=Product.objects.filter(restaurant=self.request.user.restaurant,id=pk,is_active=True).first()
		context['form']=VariantTypeForm()
		context['product']=product
		return context

	def post(self,request,pk):
		form=VariantTypeForm(request.POST)
		if form.is_valid():
			product=Product.objects.filter(restaurant=request.user.restaurant,id=pk,is_active=True).first()
			vtype=form.save(commit=False)
			vtype.restaurant=request.user.restaurant
			vtype.product=product
			vtype.save()
			return redirect('restaurant:list-variant-types',product.id)
		context={'form':form,}
		return render(request,self.template_name,context)

class EditVariantType(IsRestaurantAdminMixin,TemplateView):
	template_name='admin/edit_variant_type.html'
	def get_context_data(self,*args,**kwargs):
		context=super(EditVariantType,self).get_context_data(*args,**kwargs)
		pk=self.kwargs.get('pk')
		vtype= VariantType.objects.filter(restaurant=self.request.user.restaurant,id=pk,is_active=True).select_related('product').first()
		product=vtype.product
		if not (vtype and product):
			raise Http404
		context['form']=VariantTypeForm(instance=vtype)
		context['product']=product
		return context

	def post(self,request,pk,*args,**kwargs):
		vtype= VariantType.objects.filter(restaurant=self.request.user.restaurant,id=pk,is_active=True).select_related('product').first()
		product=vtype.product
		if not (vtype and product):
			raise Http404
		form=VariantTypeForm(request.POST,instance=vtype)
		if form.is_valid():
			form.save()
			return redirect('restaurant:list-variant-types',product.id)
		context={'form':form,'product':product}
		return render(request,self.template_name,context)


class DeleteVariantType(IsRestaurantAdminMixin,View):
	def post(self,request,pk,*args,**kwargs):
		vtype= VariantType.objects.filter(restaurant=self.request.user.restaurant,id=pk,is_active=True).select_related('product').first()
		product=vtype.product
		vtype.is_active=False
		vtype.save()
		messages.error(request,'Variant type deleted')
		return redirect('restaurant:list-variant-types',product.id)


class ListVariants(IsRestaurantAdminMixin,TemplateView):
	template_name='admin/list_variants.html'

	def get_context_data(self,*args,**kwargs):
		context=super(ListVariants,self).get_context_data(*args,**kwargs)
		pk=self.kwargs.get('pk')
		variant_type=VariantType.objects.filter(restaurant=self.request.user.restaurant,id=pk
			).select_related('product').first()
		product=variant_type.product
		variants=Variant.objects.filter(restaurant=self.request.user.restaurant,variant_type__id=pk,
			is_active=True)
		context['product']=product
		context['variant_type']=variant_type
		context['variants']=variants
		context['form']=VariantForm(variant_type=variant_type)
		return context

	def post(self,request,pk):
		variant_type=VariantType.objects.filter(restaurant=self.request.user.restaurant,id=pk
			).select_related('product').first()
		product=variant_type.product
		form=VariantForm(request.POST,variant_type=variant_type)
		if form.is_valid():
			variant=form.save(commit=False)
			variant.restaurant=request.user.restaurant
			variant.product=product
			variant.variant_type=variant_type
			variant.save()
			return redirect('restaurant:list-variants',variant_type.id)
		variants=Variant.objects.filter(restaurant=request.user.restaurant,variant_type__id=pk,
			is_active=True)
		context={'form':form,'product':product,'variant_type':variant_type,'variants':variants}
		return render(request,self.template_name,context)


class EditVariant(IsRestaurantAdminMixin,TemplateView):
	template_name='admin/edit_variant.html'

	def get_context_data(self,*args,**kwargs):
		context=super(EditVariant,self).get_context_data(*args,**kwargs)
		pk=self.kwargs.get('pk')
		variant=Variant.objects.filter(restaurant=self.request.user.restaurant,id=pk
			).select_related('product','variant_type').first()
		product=variant.product
		variant_type=variant.variant_type
		context['product']=product
		context['variant_type']=variant_type
		context['variant']=variant
		context['form']=VariantForm(instance=variant,variant_type=variant_type)
		return context

	def post(self,request,pk):
		pk=self.kwargs.get('pk')
		variant=Variant.objects.filter(restaurant=self.request.user.restaurant,id=pk
			).select_related('product','variant_type').first()
		product=variant.product
		variant_type=variant.variant_type
		form=VariantForm(request.POST,instance=variant,variant_type=variant_type)
		if form.is_valid():
			variant=form.save()
		else:
			messages.error(request,get_error(form))
		return redirect('restaurant:list-variants',variant_type.id)

class DeleteVariant(IsRestaurantAdminMixin,View):
	def post(self,request,pk,*args,**kwargs):
		var = Variant.objects.filter(restaurant=self.request.user.restaurant,id=pk,is_active=True).select_related('variant_type').first()
		vtype=var.variant_type
		var.is_active=False
		var.save()
		messages.error(request,'Variant deleted')
		return redirect('restaurant:list-variants',vtype.id)


class SetPriceOfVariants(IsRestaurantAdminMixin,TemplateView):
	template_name='admin/set_price_of_variants.html'

	def get_context_data(self,*args,**kwargs):
		context=super(SetPriceOfVariants,self).get_context_data(*args,**kwargs)
		pk=self.kwargs.get('pk')
		vtype_prefetch=Prefetch('variant_types',queryset=VariantType.objects.filter(is_active=True,
			is_addon=False),to_attr='all_variant_types')
		variants_prefetch=Prefetch('variants',queryset=Variant.objects.filter(is_active=True,
			variant_type__is_addon=False),to_attr='all_variants')
		product=Product.objects.filter(restaurant=self.request.user.restaurant,id=pk,is_active=True
			).prefetch_related(vtype_prefetch,variants_prefetch).first()
		context['product']=product
		return context

	def post(self,request,pk):
		response={'success':False}
		prices=VariantPricing.objects.filter(restaurant=self.request.user.restaurant,product__id=pk,is_active=True)

		variant_ids=[]
		for key in request.POST:
			try:
				int(key)
				val=request.POST.get(key)
				if val:
					variant_ids.append(int(val))
			except:
				pass
		price=prices.filter(variants__id__in=variant_ids).annotate(num_variants=Count('variants')).filter(
			num_variants=len(variant_ids)).first()
		try:
			new_price=float(request.POST.get('price'))
		except:
			response['reason']='Price not entered'
			return JsonResponse(response)

		if price:
			price.price=new_price
			price.save()
			response['success']=True
		else:
			pricing=VariantPricing.objects.create(restaurant=self.request.user.restaurant,product_id=pk,
				price=new_price)
			variants=Variant.objects.filter(restaurant=self.request.user.restaurant,product__id=pk,
				id__in=variant_ids)
			pricing.variants.set(variants)
			response['success']=True
		return JsonResponse(response)



class ToggleAutoDecline(IsRestaurantAdminMixin,View):
	def post(self,request):
		return_url=request.GET.get('return')
		restaurant=request.user.restaurant
		next_status=request.POST.get('next_status','').lower()
		next_status = True if next_status == 'on' else False
		if restaurant.auto_decline == next_status:
			messages.error(request,'Failed')
		else:
			restaurant.auto_decline=not restaurant.auto_decline
			restaurant.save()
			messages.success(request,'Auto decline turned '+('Off','On')[int(restaurant.auto_decline)])
		return redirect(return_url or 'restaurant:list-orders')

class GetPrice(IsRestaurantAdminMixin,View):

	def post(self,request,pk):
		response={'success':False}
		prices=VariantPricing.objects.filter(restaurant=request.user.restaurant,product__id=pk,is_active=True)
		variant_ids=[]
		for key in request.POST:
			try:
				int(key)
				val=request.POST.get(key)
				if val:
					variant_ids.append(int(val))
			except:
				pass
		price=prices.filter(variants__id__in=variant_ids).annotate(num_variants=Count('variants')).filter(
			num_variants=len(variant_ids)).first()
		if price:
			response['price']=price.price
		else:
			response['price']=None
		response['success']=True
		return JsonResponse(response)


class ListOrders(IsRestaurantAdminMixin,TemplateView):
	template_name='admin/list_orders.html'
	def get_context_data(self,*args,**kwargs):
		context=super(ListOrders,self).get_context_data(*args,**kwargs)
		
		tdate=self.request.GET.get('date')
		if tdate:
			tdate=datetime.strptime(tdate,'%Y-%m-%d').date()
		else:
			tdate=datetime.today()
		context['date']=tdate
		queryset=Order.objects.filter(Q(is_cash=True)|Q(paid=True),restaurant=self.request.user.restaurant,
			is_active=True,created__date=tdate,)
		
		filter_by=self.request.GET.get('filter','undelivered').strip()
		filter_dict={'all':{},'delivered':{'delivered':True},'undelivered':{'delivered':False,'declined':False},
			'declined':{'declined':True}}.get(filter_by)
		queryset=queryset.filter(**filter_dict).order_by('-id')
		context['object_list']=queryset
		context['filter']=filter_by
		return context

class MarkDelivered(IsRestaurantAdminMixin,View):
	def post(self,request,pk):
		return_url=request.GET.get('return')
		res=Order.objects.filter(restaurant=request.user.restaurant,id=pk,is_active=True,delivered=False
			).update(delivered=True)
		if res<1:
			messages.error(request,'failed')
		else:
			messages.success(request,'Marked delivered')
		return redirect(return_url or 'restaurant:list-orders')

class DeclineOrder(IsRestaurantAdminMixin,View):
	def post(self,request,pk):
		return_url=request.GET.get('return')
		res=Order.objects.filter(restaurant=request.user.restaurant,id=pk,is_active=True,delivered=False,
			declined=False).update(declined=True)
		if res<1:
			messages.error(request,'failed')
		else:
			messages.success(request,'Order declined')
		return redirect(return_url or 'restaurant:list-orders')
	

class OrderDetails(IsRestaurantAdminMixin,TemplateView):
	template_name='admin/order_details.html'
	def get_context_data(self,*args,**kwargs):
		pk=kwargs.get('pk')
		context=super(OrderDetails,self).get_context_data(*args,**kwargs)
		order=Order.objects.filter(restaurant=self.request.user.restaurant,pk=pk).select_related(
			'customer','customer_address').first()
		order_items=OrderItem.objects.filter(order=order).select_related('product').prefetch_related(
			'variants','variants__variant_type')
		context['order']=order
		context['order_items']=order_items
		return context

# ===========================================
# API for customers
# ===========================================

class FindRestaurant(APIView):
	permission_classes=(AllowAny,)
	authentication_classes=(CustomTokenAuthentication,)
	
	def post(self,request):
		response_dict={'success':False}

		criteria=request.data.get('criteria',{})
		location=criteria.get('location',None)
		if not location:
			address=criteria.get('address',None)
			if not address:
				response_dict['reason']='parameter `address` not received'
				return Response(response_dict,HTTP_200_OK)
			full_address=', '.join(tuple(filter(lambda i:bool(i),map(address.get,('street','apt','city','state','zipcode')))))
			
			t_dict={'state':address.get('state'),'city':address.get('city')}
			coords=GeoCodeCache.objects.filter(**t_dict).filter(address=full_address).first()
			if not coords:
				try:
					loc=geocode(full_address)
				except Exception as e:
					print('error in geocoding',e)
					response_dict['reason']='Geocoding failed'
					return Response(response_dict,HTTP_200_OK)
				loc=GeoCodeCache.objects.create(address=full_address,lat=loc['lat'],lng=loc['lng'],**t_dict)
			else:
				loc=coords
		else:
			if not ('lat' in location and 'lng' in location):
				response_dict['reason']='Invalid location'
				return Response(response_dict,HTTP_200_OK)
			loc=GeoCodeCache(lat=location['lat'],lng=location['lng'])

		order_type=criteria.get('order_type').lower()
		if not order_type or order_type not in ('pickup','delivery'):
			response_dict['reason']='`order_type` not specified'
			return Response(response_dict,HTTP_200_OK)
		restaurant_type=criteria.get('restaurant_type')
		if restaurant_type and not restaurant_type.isalpha():
			response_dict['reason']='Invalid `restaurant_type`'
			return Response(response_dict,HTTP_200_OK)
		sql_order_type_criteria="and order_types IN ( 'BOTH','"+order_type.upper()+"') "
		sql_restaurant_type="and restaurant_type = '"+restaurant_type.upper()+"' " if restaurant_type else ''
		sql_delivery_distance_clause='having distance <= max_delivery_distance ' if order_type.upper()=='DELIVERY' else ''

		# 285 MLK Blvd, Apt. 2, Newark, New Jersey, 07102

		radius=settings.MAX_SEARCH_RADIUS_IN_MILES
		lat_diff=float(radius/110.574)
		lat_diff_in_rads=float(lat_diff)*math.pi/180
		lng_diff=radius/(111.320*math.cos(lat_diff_in_rads))
		min_lat=loc.lat-lat_diff
		max_lat=loc.lat+lat_diff
		min_long=loc.lng-lng_diff
		max_long=loc.lng+lng_diff

		table_name=Restaurant._meta.db_table

		sql_query='select id, name, restaurant_type, street, floor, city, state, zipcode, '
		sql_query+='lat, lng, max_delivery_distance, order_types, '
		sql_query+='( 3959 * acos( cos( radians('+str(loc.lat)+') ) '
		sql_query+=' * cos( radians( lat ) ) '
		sql_query+=' * cos( radians( lng ) - radians('+str(loc.lng)+') ) '
		sql_query+=' + sin( radians('+str(loc.lat)+') ) '
		sql_query+=' * sin( radians( lat ) ) ) ) AS distance '
		sql_query+='from '+str(table_name)+' '
		sql_query+='where lat between '+str(min_lat)+' and '+str(max_lat)+' '
		sql_query+='and lng between '+str(min_long)+' and '+str(max_long)+' '
		sql_query+=sql_order_type_criteria
		sql_query+=sql_restaurant_type
		sql_query+=sql_delivery_distance_clause
		sql_query+='ORDER BY distance'

		
		restaurants=Restaurant.objects.raw(sql_query)
		
		restaurants_list=[]
		fields=('id','name','restaurant_type','street','floor','city','state','zipcode','lat','lng',
			'max_delivery_distance','order_types','distance','auto_decline')
		for res in restaurants:
			restaurants_list.append({ f:getattr(res,f,None) for f in fields })
		response_dict['restaurants']=restaurants_list
		response_dict['success']=True
		return Response(response_dict,HTTP_200_OK)


class GetMenu(APIView):
	permission_classes=(AllowAny,)
	authentication_classes=(CustomTokenAuthentication,)
	
	def post(self,request):
		response_dict={'success':False}
		restaurant_id=request.data.get('restaurant_id')
		res=Restaurant.objects.filter(id=restaurant_id).first()
		if not res:
			response_dict['reason']='Restaurant not found'
			return Response(response_dict,HTTP_200_OK)
		
		is_delivery=request.data.get('is_delivery',False)
		products=Product.objects.filter(restaurant=res,is_active=True)
		if is_delivery:
			products=products.exclude(is_pick_up_only=True)
		variants=Variant.objects.filter(restaurant=res,product__id__in=products.values_list('id',
			flat=True),is_active=True).values('id','variant_type__id','name','price')
		
		vtype_prefetch=Prefetch('variant_types',queryset=VariantType.objects.filter(restaurant=res,is_active=True),
			to_attr='variant_types_list')
		products=products.prefetch_related(vtype_prefetch)

		menu=[]
		for pro in products:
			pro_data=ProductSerializer(pro).data
			pro_data['variant_types']=[]
			for vtype in pro.variant_types_list:
				vtype_data=VariantTypeSerializer(vtype).data
				vtype_data['choices']=[]
				for var in variants:
					if vtype.id==var.get('variant_type__id'):
						vtype_data['choices'].append(var)
				pro_data['variant_types'].append(vtype_data)
			menu.append(pro_data)
		
		response_dict['restaurant_id']=restaurant_id
		response_dict['auto_decline']=res.auto_decline
		
		response_dict['menu']=menu
		response_dict['success']=True
		return Response(response_dict,HTTP_200_OK)


class GetPriceOfSelection(APIView):
	permission_classes=(AllowAny,)
	authentication_classes=(CustomTokenAuthentication,)
	
	def post(self,request):
		response_dict={'success':False}
		res_id=request.data.get('restaurant_id')
		product_id=request.data.get('product_id')
		product=Product.objects.filter(restaurant__id=res_id,id=product_id,is_active=True).select_related(
			'restaurant').first()
		restaurant=product.restaurant
		
		if not product:
			response_dict['reason']='Product not found'
			return Response(response_dict,HTTP_200_OK)
		
		prices=VariantPricing.objects.filter(restaurant=restaurant,product=product,is_active=True)
		variant_ids=[]
		vtypes=request.data.get('variant_types')
		for vtype in vtypes:
			key=vtype.get('id')
			choice=vtype.get('choices')
			# choices is a list
			if choice:
				variant_ids.extend(choice)
		# check redundant choices, invalid choices
		all_choices_count=Variant.objects.filter(product=product,id__in=variant_ids).count()
		if all_choices_count!=len(variant_ids):
			response_dict['reason']='Variants/choices received are invalid or redundant'
			return Response(response_dict,HTTP_200_OK)
		
		addons=Variant.objects.filter(product=product,variant_type__is_addon=True,id__in=variant_ids)
		non_addons=Variant.objects.filter(product=product,variant_type__is_addon=False,id__in=variant_ids)
		# get price of non addon variant combination
		non_addons_ids=tuple(non_addons.values_list('id',flat=True))
		non_addons_count=len(non_addons_ids)

		# required check
		no_of_required=VariantType.objects.filter(restaurant=restaurant,product=product,required=True,is_active=True).count()
		no_of_selected_required=Variant.objects.filter(variant_type__required=True,id__in=variant_ids).values('variant_type').annotate(
			vcount=Count('variant_type')).count()
		if no_of_required!=no_of_selected_required:
			response_dict['reason']='Please select all required options'
			return Response(response_dict,HTTP_200_OK)
		
		# check if multiple choices entered while allow_multiple=False
		multiple_not_allowed=tuple(Variant.objects.filter(id__in=variant_ids).filter(Q(variant_type__is_addon=False)|Q(variant_type__allow_multiple=False)
			).values('variant_type','variant_type__name').annotate(vcount=Count('variant_type')).filter(vcount__gt=1).values_list(
			'variant_type__name',flat=True))
		if multiple_not_allowed:
			response_dict['reason']='Multiple choices are not allowed for '+', '.join(multiple_not_allowed)
			return Response(response_dict,HTTP_200_OK)

		
		if non_addons_count>0:
			price=prices.filter(variants__id__in=non_addons_ids).annotate(num_variants=Count('variants')).filter(
				num_variants=non_addons_count).first()
			if price:
				price_final=price.price
			else:
				response_dict['reason']='Combination not available or price not set'
				return Response(response_dict,HTTP_200_OK)
		else:
			price_final=product.base_price

		# calculate add-on prices (consider multiple choices)
		price_final+=addons.aggregate(price_sum=Sum('price')).get('price_sum',0) or 0

		response_dict['price']=price_final
		response_dict['auto_decline']=restaurant.auto_decline
		response_dict['success']=True
		return Response(response_dict,HTTP_200_OK)



class PlaceOrder(APIView):
	permission_classes=(IsActiveUser,IsCustomer,)
	authentication_classes=(CustomTokenAuthentication,)
	
	def post(self,request):
		response_dict={'success':False}
		res_id=request.data.get('restaurant_id')
		res=Restaurant.objects.filter(id=res_id).first()
		if not res:
			response_dict['reason']='Unknown restaurant'
			return Response(response_dict,HTTP_200_OK)

		if res.auto_decline:
			response_dict['auto_decline']=res.auto_decline
			response_dict['reason']="Sorry. This restaurant can't take on more customers right now"
			return Response(response_dict,HTTP_200_OK)

		is_delivery=request.data.get('is_delivery',None)
		if is_delivery not in (True,False):
			response_dict['reason']='invalid value for `is_delivery`'
			return Response(response_dict,HTTP_200_OK)
		order_type= 'DELIVERY' if is_delivery else 'PICKUP'

		schedule_date_time=None
		schedule=request.data.get('schedule',None)
		if schedule:
			schedule_date=schedule.get('date',None)
			schedule_time=schedule.get('time',None)
			try:
				schedule_date_time=datetime.strptime(schedule_date+' '+schedule_time,'%d-%m-%Y %H:%M')
				if schedule_date_time<datetime.now()+timedelta(minutes=30):
					response_dict['reason']='Schedule time is too early'
					return Response(response_dict,HTTP_200_OK)
			except:
				response_dict['reason']='Invalid date time format (expects: dd-mm-yyyy HH:MM)'
				return Response(response_dict,HTTP_200_OK)

		customer=request.data.get('customer')
		if not customer:
			response_dict['reason']='Customer details not supplied'
			return Response(response_dict,HTTP_200_OK)
		address=customer.get('address')
		if not address:
			response_dict['reason']='Address not provided'
			return Response(response_dict,HTTP_200_OK)
		new_address=False
		if address.get('isNew',False):
			new_address=True
			serializer=CustomerAddressSerializer(data=address)
			if serializer.is_valid():
				cust_address=CustomerAddress(**serializer.validated_data)
				cust_address.customer=request.user
			else:
				response_dict['reason']='Address:'+get_error(serializer)
				return Response(response_dict,HTTP_200_OK)
		else:
			address_id=address.get('id')
			if not address_id:
				response_dict['reason']='Address id not received'
				return Response(response_dict,HTTP_200_OK)
			cust_address=CustomerAddress.objects.filter(customer=request.user,id=address_id).first()
			if not cust_address:
				response_dict['reason']='Customer address not found'
				return Response(response_dict,HTTP_200_OK)
		
		promo_code=request.data.get('promoCode',None) or None
		usage_count=None
		if promo_code:
			today=datetime.today()
			promo_code=PromoCode.objects.filter( Q(Q(restaurants__id=res_id)|Q(all_restaurants=True)) &
				Q( Q(customers=request.user)|Q(all_customers=True) ),code=promo_code,is_active=True,
				valid_from__lte=today,valid_till__gte=today).first()
			usage_count=PromoCodeUsage.objects.filter(promo_code=promo_code,customer=request.user).first()
			if usage_count and usage_count.usage_count >= promo_code.max_usage:
				response_dict['reason']='You have reached the maximum usage limit of this promo code'
				return Response(response_dict,HTTP_200_OK)
			if not promo_code:
				response_dict['reason']='Promo code entered is invalid or expired'
				return Response(response_dict,HTTP_200_OK)
		
		products=request.data.get('orderItemsList')
		product_ids=tuple(map(lambda i:i['id'],products))
		product_objs=Product.objects.filter(restaurant=res,id__in=product_ids,is_active=True)
		
		if len(product_objs)!=len(product_ids):
			response_dict['reason']='Some of the selected items are not found'
			return Response(response_dict,HTTP_200_OK)
		
		order_total=0
		order_items=[]
		for product in products:
			product_obj=next(filter(lambda i:i.id==product['id'],product_objs))
			qty=product['itemQuantity']
			vtypes=product['itemToppings']
			prices=VariantPricing.objects.filter(restaurant=res,product=product_obj,is_active=True)
			variant_ids=[]
			for vtype in vtypes:
				# key=vtype.get('id')
				choices=vtype.get('choices')
				choice_ids=tuple(map(lambda i:i['id'],choices))
				# choices is a list
				if choice_ids:
					variant_ids.extend(choice_ids)
			
			all_choices=Variant.objects.filter(product=product_obj,id__in=variant_ids)
			all_choices_count=all_choices.count()
			if all_choices_count!=len(variant_ids):
				response_dict['reason']='Variants/choices received are invalid or redundant for '+product_obj.name
				return Response(response_dict,HTTP_200_OK)

			addons=Variant.objects.filter(product=product_obj,variant_type__is_addon=True,id__in=variant_ids)
			non_addons=Variant.objects.filter(product=product_obj,variant_type__is_addon=False,id__in=variant_ids)
			# get price of non addon variant combination
			non_addons_ids=tuple(non_addons.values_list('id',flat=True))
			non_addons_count=len(non_addons_ids)

			# required check
			no_of_required=VariantType.objects.filter(restaurant=res,product=product_obj,required=True,
				is_active=True).count()
			no_of_selected_required=Variant.objects.filter(product=product_obj,variant_type__required=True,
				id__in=variant_ids).values('variant_type').annotate(vcount=Count('variant_type')).count()
			if no_of_required!=no_of_selected_required:
				response_dict['reason']='Please select all required options for '+product_obj.name
				return Response(response_dict,HTTP_200_OK)
			
			# check if multiple choices entered while allow_multiple=False
			multiple_not_allowed=tuple(Variant.objects.filter(product=product_obj,id__in=variant_ids).filter(
				Q(variant_type__is_addon=False)|Q(variant_type__allow_multiple=False)).values('variant_type',
				'variant_type__name').annotate(vcount=Count('variant_type')).filter(vcount__gt=1).values_list(
				'variant_type__name',flat=True))
			if multiple_not_allowed:
				response_dict['reason']='Multiple choices are not allowed for '+', '.join(multiple_not_allowed)+' of '+product_obj.name
				return Response(response_dict,HTTP_200_OK)

			product_price=0
			if non_addons_count>0:
				price=prices.filter(variants__id__in=non_addons_ids).annotate(num_variants=Count('variants')).filter(
					num_variants=non_addons_count).first()
				if price:
					product_price=price.price
				else:
					response_dict['reason']='Combination not available or price not set'
					return Response(response_dict,HTTP_200_OK)
			else:
				product_price=product_obj.base_price

			# calculate add-on prices (consider multiple choices)
			product_price+=addons.aggregate(price_sum=Sum('price')).get('price_sum',0) or 0
			product_price_sum=qty*product_price

			t_item={
				'product_price':product_price,
				'variants':all_choices,
				'item':OrderItem(restaurant=res,customer=request.user,product=product_obj,quantity=qty,
					total_price=product_price_sum)
				}
			order_items.append(t_item)
			order_total+=product_price_sum

		amount_payable=order_total
		if promo_code:
			if order_total < promo_code.min_order_amount:
				response_dict['reason']='This promo code is valid only for orders of minimum '+str(promo_code.min_order_amount)
				return Response(response_dict,HTTP_200_OK)
			if promo_code.promo_type=='FLAT_PERCENTAGE_DISCOUNT':
				discount=order_total*promo_code.discount/100
				amount_payable=order_total-discount
			elif promo_code.promo_type=='FIXED_DISCOUNT':
				amount_payable=order_total-promo_code.discount
			else:
				response_dict['reason']='Invalid promo code'
				return Response(response_dict,HTTP_200_OK)

		payment_details=request.data.get('payment')
		if not payment_details:
			response_dict['reason']='Payment method not selected'
			return Response(response_dict,HTTP_200_OK)
		isCashPayment=payment_details.get('isCash',False)
		new_payment_method=False
		card_tip=0
		if not isCashPayment:
			new_payment_method=payment_details.get('isNew',False)
			card_tip=payment_details.get('cardTip',0)
			if new_payment_method:
				serializer=PaymentMethodSerializer(data=payment_details)
				if serializer.is_valid():
					payment_method=PaymentMethod(customer=request.user,**serializer.validated_data)
				else:
					response_dict['reason']=get_error(serializer)
					return Response(response_dict,HTTP_200_OK)
			else:
				p_method_id=payment_details.get('id')
				payment_method=PaymentMethod.objects.filter(customer=request.user,id=p_method_id).first()

		with transaction.atomic():
			if new_address:
				cust_address.save()
			if new_payment_method:
				payment_method.save()
			order=Order(restaurant=res,customer=request.user,order_type=order_type,is_cash=isCashPayment,
				promo_code=promo_code,customer_address=cust_address,total=order_total,amount_payable=amount_payable,
				schedule=schedule_date_time)
			if not isCashPayment:
				order.payment_method=payment_method
				order.card_tip=card_tip
			order.save()
			for t_item in order_items:
				t_item['item'].order=order
				t_item['item'].save()
				t_item['item'].variants.set(t_item['variants'])
			if promo_code:
				if usage_count:
					usage_count.usage_count+=1
					usage_count.save()
				else:
					PromoCodeUsage.objects.create(customer=request.user,promo_code=promo_code,usage_count=1)

			response_dict['order_id']=order.id
			response_dict['order_total']=order_total
			response_dict['amount_payable']=amount_payable
			response_dict['is_cash']=isCashPayment
			response_dict['success']=True

		return Response(response_dict,HTTP_200_OK)


