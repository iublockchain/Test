from django import forms
from restaurant.models import Restaurant,Product,VariantType,Variant
from user.models import UserProfile
from Project.utils import validate_password


class RestaurantForm(forms.ModelForm):
    class Meta:
        model=Restaurant
        fields=('name','restaurant_type','street','floor','city','state','zipcode','order_types',
            'max_delivery_distance','image','lat','lng')
        widgets={
            'max_delivery_distance':forms.NumberInput(attrs={'min':0.5,'max':5,'step':0.1})
        }

class RestaurantAdminForm(forms.ModelForm):
    confirm_password    =   forms.CharField(required=True,widget=forms.PasswordInput())
    class Meta:
        model=UserProfile
        fields=('email','first_name','last_name','phone','password')
        widgets={'password':forms.PasswordInput()}

    def __init__(self, *args, **kwargs):
        self.no_password=kwargs.pop('no_password',False)
        super(RestaurantAdminForm,self).__init__(*args,**kwargs)
        if self.no_password:
            self.fields.pop('password')
            self.fields.pop('confirm_password')

    def clean(self,*args,**kwargs):
        cleaned_data=super(RestaurantAdminForm,self).clean(*args,**kwargs)
        if not self.no_password:
            pwd=cleaned_data.get('password')
            c_pwd=cleaned_data.get('confirm_password')
            if pwd!=c_pwd:
                self.add_error('password','Password do not match')
            res,msg=validate_password(pwd)
            if not res:
                self.add_error('password',msg)
        return cleaned_data


class ProductForm(forms.ModelForm):
    class Meta:
        model=Product
        fields=('name','level1','level2','level3','base_price','image','is_pick_up_only')
        help_texts = {
                'base_price': ('This price will be considered only if none of the selected variants affect pricing'),
        }

class VariantTypeForm(forms.ModelForm):
    class Meta:
        model=VariantType
        fields=('name','category','required','allow_multiple','is_addon')

    def clean(self,*args,**kwargs):
        cleaned_data=super(VariantTypeForm,self).clean(*args,**kwargs)
        allow_multiple=cleaned_data.get('allow_multiple',False)
        if allow_multiple:
            if not cleaned_data.get('is_addon',False):
                self.add_error('allow_multiple','Multiple choices are not allowed for variant type unless it is an add-on')
        return cleaned_data

class VariantForm(forms.ModelForm):
    class Meta:
        model=Variant
        fields=('name','price')
    
    def __init__(self,*args,**kwargs):
        self.variant_type=kwargs.pop('variant_type',None)
        if not self.variant_type:
            raise ValueError('`variant_type` not received')
        super(VariantForm,self).__init__(*args,**kwargs)
        if not self.variant_type.is_addon:
            self.fields.pop('price')



