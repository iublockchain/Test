from django.contrib import admin
from restaurant.models import Product,ProductTag,VariantType,Variant,VariantPricing,Order,\
    OrderItem,PaymentMethod,PromoCode,GeoCodeCache,Cart,CartItem

admin.site.register(Product)
admin.site.register(ProductTag)
admin.site.register(VariantType)
admin.site.register(Variant)
admin.site.register(VariantPricing)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(PaymentMethod)
admin.site.register(PromoCode)
admin.site.register(GeoCodeCache)
admin.site.register(Cart)
admin.site.register(CartItem)
